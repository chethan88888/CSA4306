# TechSavvy — Question project

## Run the website
1. Extract this ZIP file.
2. Open the extracted folder in Visual Studio Code.
3. Open `index.html` with Live Server, or double-click `index.html`.

## Files
- `index.html` — website layout and content
- `style.css` — responsive styling
- `script.js` — interactions and form handling

## Working demo features
- Responsive page for desktop and mobile
- Working navigation and featured cards
- Add-to-cart, remove/clear cart, checkout validation, and demo order stored in browser localStorage

## Limitations
This is a front-end demo, not a production service. No real database, authentication, live payments, maps, email or SMS integrations are included.
