<?php $page_title="FAQ"; require "partials_header.php"; $rows=$conn->query("SELECT * FROM faq ORDER BY id"); ?>
<section class="page-banner"><p class="eyebrow">NEED TO KNOW</p><h1>Customer service Q&A</h1></section>
<section class="section narrow"><?php while($f=$rows->fetch_assoc()):?><details><summary><?=h($f['question'])?></summary><p><?=nl2br(h($f['answer']))?></p></details><?php endwhile;?></section>
<?php require "partials_footer.php"; ?>