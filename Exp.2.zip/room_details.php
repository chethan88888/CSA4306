<?php
$page_title = "Room Details";
require "partials_header.php";
$id = (int)($_GET['id'] ?? 0);
$stmt = $conn->prepare("SELECT * FROM rooms WHERE id=?");
$stmt->bind_param("i",$id); $stmt->execute();
$r = $stmt->get_result()->fetch_assoc();
if (!$r) { echo "<section class='section'><h2>Room not found.</h2></section>"; require "partials_footer.php"; exit; }
?>
<section class="detail-hero"><div class="room-image <?= strtolower($r['room_type']) ?>"></div><div><p class="eyebrow"><?= h($r['room_type']) ?></p><h1><?= h($r['title']) ?></h1><p><?= h($r['description']) ?></p><h2>₹<?= number_format($r['price']) ?><small>/night</small></h2><a class="button" href="booking.php?room_id=<?= $r['id'] ?>">Reserve this room</a></div></section>
<section class="section narrow"><p class="eyebrow">AMENITIES</p><h2>Everything you need.</h2><div class="amenity-grid"><?php foreach(explode(',', $r['amenities']) as $a): ?><div>✦ <?= h(trim($a)) ?></div><?php endforeach; ?></div></section>
<?php require "partials_footer.php"; ?>