CREATE DATABASE IF NOT EXISTS hotel_booking;
USE hotel_booking;

CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(150) UNIQUE NOT NULL,
 password VARCHAR(255) NOT NULL,
 phone VARCHAR(30),
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS admins (
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50) UNIQUE NOT NULL,
 password VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS rooms (
 id INT AUTO_INCREMENT PRIMARY KEY,
 room_type VARCHAR(50) NOT NULL,
 title VARCHAR(150) NOT NULL,
 description TEXT,
 price DECIMAL(10,2) NOT NULL,
 quantity INT NOT NULL DEFAULT 1,
 amenities VARCHAR(500),
 image VARCHAR(255),
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bookings (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 room_id INT NOT NULL,
 check_in DATE NOT NULL,
 check_out DATE NOT NULL,
 guests INT NOT NULL DEFAULT 1,
 rooms_count INT NOT NULL DEFAULT 1,
 total_amount DECIMAL(10,2) NOT NULL,
 status ENUM('Confirmed','Pending','Cancelled','Completed') DEFAULT 'Confirmed',
 payment_status ENUM('Paid','Pending','Refunded') DEFAULT 'Pending',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS reviews (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 room_id INT NOT NULL,
 rating INT NOT NULL,
 review TEXT,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS pages (
 id INT AUTO_INCREMENT PRIMARY KEY,
 page_key VARCHAR(50) UNIQUE NOT NULL,
 title VARCHAR(150) NOT NULL,
 content TEXT
);

CREATE TABLE IF NOT EXISTS faq (
 id INT AUTO_INCREMENT PRIMARY KEY,
 question VARCHAR(255) NOT NULL,
 answer TEXT NOT NULL
);

INSERT INTO admins (username,password)
SELECT 'admin','admin123'
WHERE NOT EXISTS (SELECT 1 FROM admins WHERE username='admin');

INSERT INTO rooms (room_type,title,description,price,quantity,amenities,image)
SELECT * FROM (
 SELECT 'Standard','Serene Standard Room','Comfortable room for a relaxing stay.',2000,10,'Wi-Fi, AC, TV, Breakfast','standard.jpg'
 UNION ALL
 SELECT 'Deluxe','Deluxe City View','Elegant room with beautiful city views.',3500,8,'Wi-Fi, AC, TV, Breakfast, Mini Bar','deluxe.jpg'
 UNION ALL
 SELECT 'Executive','Executive Business Room','Premium room designed for business and leisure.',5000,6,'Wi-Fi, AC, Work Desk, Breakfast, Mini Bar','executive.jpg'
 UNION ALL
 SELECT 'Suite','Grand Luxury Suite','Spacious luxury suite with premium facilities.',8000,4,'Wi-Fi, AC, Living Area, Breakfast, Mini Bar, Bathtub','suite.jpg'
) AS tmp
WHERE NOT EXISTS (SELECT 1 FROM rooms LIMIT 1);

INSERT INTO pages(page_key,title,content)
SELECT 'about','About Us','Welcome to Luma Grand Hotel — comfort, elegance and memorable stays.'
WHERE NOT EXISTS (SELECT 1 FROM pages WHERE page_key='about');

INSERT INTO pages(page_key,title,content)
SELECT 'contact','Contact Us','Phone: +91 98765 43210 | Email: stay@lumagrand.com | Open 24/7'
WHERE NOT EXISTS (SELECT 1 FROM pages WHERE page_key='contact');

INSERT INTO pages(page_key,title,content)
SELECT 'travel','Local Travel Guide','Airport, railway station, city museum, shopping district and popular restaurants are nearby.'
WHERE NOT EXISTS (SELECT 1 FROM pages WHERE page_key='travel');

INSERT INTO pages(page_key,title,content)
SELECT 'privacy','Privacy Policy','We protect customer account, booking and payment information and use it only to provide hotel services.'
WHERE NOT EXISTS (SELECT 1 FROM pages WHERE page_key='privacy');

INSERT INTO faq(question,answer)
SELECT 'What time is check-in?','Check-in starts at 2:00 PM.'
WHERE NOT EXISTS (SELECT 1 FROM faq);

INSERT INTO faq(question,answer)
SELECT 'Can I cancel my booking?','Eligible bookings can be cancelled up to 3 days before arrival.'
WHERE NOT EXISTS (SELECT 1 FROM faq LIMIT 1);
