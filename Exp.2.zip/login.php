<?php
$page_title="Login"; require "partials_header.php"; $error="";
if ($_SERVER['REQUEST_METHOD']==='POST') {
 $email=trim($_POST['email']); $password=$_POST['password'];
 $stmt=$conn->prepare("SELECT * FROM users WHERE email=?"); $stmt->bind_param("s",$email); $stmt->execute(); $u=$stmt->get_result()->fetch_assoc();
 if($u && password_verify($password,$u['password'])){ $_SESSION['user_id']=$u['id']; $_SESSION['user_name']=$u['name']; header("Location: my_bookings.php"); exit; }
 $error="Invalid email or password.";
}
?>
<section class="auth-page"><div class="auth-card"><p class="eyebrow">MEMBER LOGIN</p><h1>Welcome back.</h1><?php if(isset($_GET['registered'])):?><div class="success">Account created. Please sign in.</div><?php endif;?><?php if($error):?><div class="alert"><?=h($error)?></div><?php endif;?><form method="post" class="form"><input type="email" name="email" placeholder="Email address" required><input type="password" name="password" placeholder="Password" required><button class="button">Sign in</button></form><p>New here? <a href="register.php">Create an account</a></p></div></section>
<?php require "partials_footer.php"; ?>