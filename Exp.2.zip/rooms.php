<?php
$page_title = "Rooms";
require "partials_header.php";
$check_in = $_GET['check_in'] ?? '';
$check_out = $_GET['check_out'] ?? '';
$guests = (int)($_GET['guests'] ?? 1);
$result = $conn->query("SELECT * FROM rooms ORDER BY price");
?>
<section class="page-banner"><p class="eyebrow">STAY YOUR WAY</p><h1>Rooms & Suites</h1><p>Choose a room that matches your pace.</p></section>
<section class="section">
<div class="room-grid">
<?php while ($r = $result->fetch_assoc()): ?>
<article class="room-card">
 <div class="room-image <?= strtolower($r['room_type']) ?>"></div>
 <div class="room-info">
  <p class="muted"><?= h($r['room_type']) ?> · <?= $r['quantity'] ?> rooms</p>
  <h3><?= h($r['title']) ?></h3>
  <p><?= h($r['description']) ?></p>
  <p class="amenities"><?= h($r['amenities']) ?></p>
  <div class="card-bottom"><strong>₹<?= number_format($r['price']) ?><small>/night</small></strong><a href="room_details.php?id=<?= $r['id'] ?><?= $check_in ? '&check_in='.urlencode($check_in).'&check_out='.urlencode($check_out).'&guests='.$guests : '' ?>">Book →</a></div>
 </div>
</article>
<?php endwhile; ?>
</div>
</section>
<?php require "partials_footer.php"; ?>