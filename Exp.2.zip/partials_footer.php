</main>
<footer class="footer">
  <div><strong>LUMA GRAND</strong><br><small>Stay beautifully. Travel freely.</small></div>
  <div><a href="travel.php">Travel Guide</a> · <a href="privacy.php">Privacy</a> · <a href="contact.php">Contact</a></div>
  <div>© <?= date('Y') ?> Luma Grand Hotel</div>
</footer>
</body>
</html>