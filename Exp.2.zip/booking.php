<?php
$page_title="Book a Room"; require "partials_header.php";
if(!isLoggedIn()){ header("Location: login.php"); exit; }
$room_id=(int)($_GET['room_id']??$_POST['room_id']??0);
$stmt=$conn->prepare("SELECT * FROM rooms WHERE id=?"); $stmt->bind_param("i",$room_id); $stmt->execute(); $room=$stmt->get_result()->fetch_assoc();
$error=""; $success="";
if($_SERVER['REQUEST_METHOD']==='POST'){
 $ci=$_POST['check_in']; $co=$_POST['check_out']; $guests=(int)$_POST['guests']; $count=(int)$_POST['rooms_count'];
 $d1=new DateTime($ci); $d2=new DateTime($co); $nights=(int)$d1->diff($d2)->days;
 if($nights<1) $error="Check-out must be after check-in.";
 elseif($count>$room['quantity']) $error="Not enough rooms available.";
 else{
   $total=$nights*$room['price']*$count;
   $stmt=$conn->prepare("INSERT INTO bookings(user_id,room_id,check_in,check_out,guests,rooms_count,total_amount,status,payment_status) VALUES(?,?,?,?,?,?,?,'Confirmed','Paid')");
   $stmt->bind_param("iissiid",$_SESSION['user_id'],$room_id,$ci,$co,$guests,$count,$total);
   if($stmt->execute()) header("Location: booking_success.php?id=".$conn->insert_id);
 }
}
?>
<section class="auth-page"><div class="booking-card"><p class="eyebrow"><?=h($room['room_type'])?></p><h1><?=h($room['title'])?></h1><p><?=h($room['description'])?></p><?php if($error):?><div class="alert"><?=h($error)?></div><?php endif;?><form method="post" class="form"><input type="hidden" name="room_id" value="<?=$room_id?>"><label>Check-in<input type="date" name="check_in" required></label><label>Check-out<input type="date" name="check_out" required></label><label>Guests<input type="number" name="guests" min="1" value="2" required></label><label>Rooms<input type="number" name="rooms_count" min="1" max="<?=$room['quantity']?>" value="1" required></label><button class="button">Confirm & Pay ₹<?=number_format($room['price'])?>/night</button></form></div></section>
<?php require "partials_footer.php"; ?>