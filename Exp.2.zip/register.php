<?php
$page_title="Create Account"; require "partials_header.php"; $error="";
if ($_SERVER['REQUEST_METHOD']==='POST') {
 $name=trim($_POST['name']); $email=trim($_POST['email']); $password=$_POST['password']; $phone=trim($_POST['phone']);
 $hash=password_hash($password,PASSWORD_DEFAULT);
 $stmt=$conn->prepare("INSERT INTO users(name,email,password,phone) VALUES(?,?,?,?)");
 $stmt->bind_param("ssss",$name,$email,$hash,$phone);
 if($stmt->execute()){ header("Location: login.php?registered=1"); exit; }
 $error="Email may already be registered.";
}
?>
<section class="auth-page"><div class="auth-card"><p class="eyebrow">WELCOME TO LUMA</p><h1>Create your account</h1><?php if($error): ?><div class="alert"><?=h($error)?></div><?php endif; ?><form method="post" class="form"><input name="name" placeholder="Full name" required><input type="email" name="email" placeholder="Email address" required><input name="phone" placeholder="Phone number"><input type="password" name="password" placeholder="Password" required><button class="button">Create account</button></form><p>Already a member? <a href="login.php">Sign in</a></p></div></section>
<?php require "partials_footer.php"; ?>