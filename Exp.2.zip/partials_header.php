<?php require_once __DIR__ . "/config.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= h($page_title ?? 'Luma Grand Hotel') ?></title>
<link rel="stylesheet" href="css/style.css">
</head>
<body>
<header class="nav">
  <a class="brand" href="index.php"><span>LG</span> LUMA GRAND</a>
  <nav>
    <a href="rooms.php">Rooms</a>
    <a href="about.php">About</a>
    <a href="contact.php">Contact</a>
    <a href="faq.php">FAQ</a>
    <?php if (isLoggedIn()): ?>
      <a href="my_bookings.php">My Bookings</a>
      <a class="nav-btn" href="logout.php">Logout</a>
    <?php else: ?>
      <a href="login.php">Login</a>
      <a class="nav-btn" href="register.php">Register</a>
    <?php endif; ?>
  </nav>
</header>
<main>
