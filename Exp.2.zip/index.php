<?php
$page_title = "Luma Grand Hotel";
require "partials_header.php";
?>
<section class="hero">
  <div class="hero-overlay">
    <p class="eyebrow">LUXURY • COMFORT • EXPERIENCE</p>
    <h1>Your next stay,<br><em>beautifully made.</em></h1>
    <p class="hero-copy">Discover elegant rooms, thoughtful amenities and a seamless booking experience.</p>
    <form class="search-box" action="rooms.php" method="get">
      <div><label>DESTINATION</label><input name="destination" value="Luma Grand Hotel"></div>
      <div><label>CHECK-IN</label><input type="date" name="check_in" required></div>
      <div><label>CHECK-OUT</label><input type="date" name="check_out" required></div>
      <div><label>GUESTS</label><input type="number" name="guests" min="1" value="2"></div>
      <button>SEARCH ROOMS</button>
    </form>
  </div>
</section>

<section class="section">
  <div class="section-head"><div><p class="eyebrow">OUR COLLECTION</p><h2>Rooms with character.</h2></div><a class="text-link" href="rooms.php">View all rooms →</a></div>
  <div class="room-grid">
    <?php
      $result = $conn->query("SELECT * FROM rooms ORDER BY price LIMIT 4");
      while ($r = $result->fetch_assoc()):
    ?>
    <article class="room-card">
      <div class="room-image <?= strtolower($r['room_type']) ?>"></div>
      <div class="room-info">
        <p class="muted"><?= h($r['room_type']) ?></p>
        <h3><?= h($r['title']) ?></h3>
        <p><?= h($r['description']) ?></p>
        <div class="card-bottom"><strong>₹<?= number_format($r['price']) ?><small>/night</small></strong><a href="room_details.php?id=<?= $r['id'] ?>">Explore →</a></div>
      </div>
    </article>
    <?php endwhile; ?>
  </div>
</section>

<section class="split-section">
  <div class="split-copy"><p class="eyebrow">THE LUMA EXPERIENCE</p><h2>Designed for slow mornings and memorable nights.</h2><p>From thoughtful room design to warm hospitality, every detail is created to make your stay effortless.</p><a class="button" href="about.php">Discover our story</a></div>
  <div class="feature-panel"><div><b>24/7</b><span>Guest service</span></div><div><b>4.9/5</b><span>Guest rating</span></div><div><b>10+</b><span>Premium amenities</span></div></div>
</section>
<?php require "partials_footer.php"; ?>