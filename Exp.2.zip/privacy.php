<?php
$page_title="Privacy Policy"; require "partials_header.php";
$stmt=$conn->prepare("SELECT title,content FROM pages WHERE page_key=?"); $k="privacy"; $stmt->bind_param("s",$k); $stmt->execute(); $p=$stmt->get_result()->fetch_assoc();
?>
<section class="page-banner"><p class="eyebrow">LUMA GRAND</p><h1><?=h($p['title']??'Privacy Policy')?></h1></section><section class="section narrow content-page"><p><?=nl2br(h($p['content']??''))?></p></section>
<?php require "partials_footer.php"; ?>