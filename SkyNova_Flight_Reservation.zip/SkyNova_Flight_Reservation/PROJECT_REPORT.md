# Online Flight Reservation System — Lab Project Report

## Aim
To design a responsive web-based flight reservation prototype that demonstrates flight search, seat selection, passenger booking, simulated payment, ticket generation, booking management, customer feedback and administrator reporting.

## Software and Technologies
- HTML5 — page structure and forms
- CSS3 — responsive layouts, transitions and animations
- JavaScript — search, validation, booking, seat selection, PNR generation and dashboard logic
- Browser localStorage — demo persistence

## Modules
1. Administrator login and dashboard
2. Passenger registration and login
3. Forgot-password demonstration
4. Search flights by route, departure date, trip type and class
5. Flight results, fare and sample seat availability
6. Seat selection and passenger details
7. Simulated ticket payment
8. E-ticket / booking reference generation and printing
9. My ticket and booking history
10. Booking status lookup
11. Ticket cancellation and estimated refund
12. Customer feedback
13. Admin flight schedule, user, booking and payment management
14. Printable admin report

## Workflow
1. The customer registers or logs in.
2. The customer searches flights by origin, destination, date, class and number of travellers.
3. The system displays matching sample flights, prices and seat availability.
4. The customer selects seats and enters passenger/contact details.
5. The customer chooses the simulated payment method.
6. The system records the demo reservation and generates a booking reference.
7. The customer views or prints the e-ticket from the dashboard and can check booking status.
8. The customer can request cancellation; a sample refund amount is recorded.
9. The administrator manages sample flight schedules and reviews reservations, accounts, payments and feedback.

## Test Cases
| Test case | Expected output |
|---|---|
| Search a matching city pair | Matching sample flights are listed |
| Same origin and destination | Validation message appears |
| Login with demo passenger credentials | Passenger dashboard opens |
| Select required seats | Seats are highlighted |
| Complete demo payment | Booking reference and e-ticket appear |
| Search using a generated reference | Booking status is displayed |
| Print e-ticket | Browser print dialog opens |
| Cancel a ticket | Status changes to Cancelled and sample refund is recorded |
| Admin adds a flight | New sample flight is stored locally |
| Submit feedback | Feedback is stored and visible to admin |
| Generate admin report | Printable report opens |
| Resize to mobile width | Page layout adapts to smaller screens |

## Conclusion
SkyNova demonstrates the primary user interface and workflow of an online flight reservation website. Production use requires secure server-side authentication, database storage, authorized flight inventory/GDS integration, real payment processing, and email notification services.
