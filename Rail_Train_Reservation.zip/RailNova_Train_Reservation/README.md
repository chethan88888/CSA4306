# RailNova — Online Train Reservation System

A responsive, animated front-end mini project for an online railway reservation system. Built with **HTML, CSS and vanilla JavaScript**. No Node.js, database server or console commands are needed.

## Run the project
1. Extract `RailNova_Train_Reservation.zip`.
2. Open the extracted folder.
3. Double-click `index.html` to open it in Chrome/Edge, or open the folder in VS Code and use Live Server.
4. Internet is needed for the Google font and Unsplash photography. The interface and booking logic otherwise run in the browser.

## Demo logins
- **Passenger:** `passenger@railnova.demo` / `demo123`
- **Admin:** `admin@railnova.demo` / `admin123`

## Features
- Responsive home page with animated travel imagery, floating cards and transitions.
- Search sample trains by origin, destination, date and class.
- Sample train timings, fares and seat availability.
- Passenger registration and login.
- Passenger details and passenger count during booking.
- Simulated online/offline payment flow.
- Automatically generated 10-digit demo PNR and ticket.
- PNR status lookup.
- Passenger dashboard, booking history, profile editing, ticket printing and cancellation.
- Demo refund calculation based on journey date.
- Admin panel for train schedules, reservations, user list and demo payment records.
- Local browser storage, so demo accounts and bookings persist in the same browser.

## Important project limitations
This is a **front-end educational demonstration**, not a production railway booking system.
- Train schedules, availability, fares and PNR status are sample data, not connected to Indian Railways or IRCTC.
- Payments are simulated; no real money is charged.
- Email/SMS notifications are not sent.
- Data is stored in the current browser using `localStorage`, not a secure shared database.
- Passwords are stored in browser storage for demo purposes only. Do not use real passwords or personal information.
- Cancellation/refund percentages are sample project rules, not official railway refund policy.
- PNR values generated here are demo identifiers and are not valid railway PNRs.

## Suggested future improvements
For a production-grade version, connect a secure backend and database, hashed passwords, verified payment gateway, authorized train inventory API, email/SMS provider, server-side cancellation/refund processing, and role-based authorization.
