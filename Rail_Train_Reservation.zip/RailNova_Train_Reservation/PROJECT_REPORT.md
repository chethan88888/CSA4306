# Online Train Reservation System — Project Summary

## Aim
To develop a responsive web application prototype that demonstrates train search, reservation, passenger account management, PNR checking, ticket printing, cancellation, refund estimation and administrator management.

## Technologies
- HTML5: page structure and forms
- CSS3: responsive layout, animation, transitions and visual styling
- JavaScript: search, validation, booking workflow, demo payment, PNR generation and dashboard actions
- Browser localStorage: local demonstration data persistence

## Modules
1. **Passenger account:** Register, log in and maintain a basic profile.
2. **Train search:** Search sample train services by route, journey date and class.
3. **Seat availability:** Displays sample capacity and reduces availability based on non-cancelled demo bookings for the selected train/date.
4. **Reservation:** Collects passenger details and number of passengers.
5. **Payment:** Simulates online or offline payment and records the demo transaction.
6. **PNR and ticket:** Generates a 10-digit sample PNR, displays status and prints a ticket.
7. **Cancellation and refund:** Cancels the booking and records an estimated refund according to a clearly labelled sample rule.
8. **Admin:** Add/edit/delete sample train schedules and view bookings, users and demo payments.

## Basic workflow
1. Passenger registers or logs in.
2. Passenger selects origin, destination, date and travel class.
3. System lists matching sample trains and availability.
4. Passenger selects a train and enters passenger details.
5. Passenger selects a demo payment method and completes the simulated payment.
6. System creates a reservation, demo PNR and printable ticket.
7. Passenger checks PNR status or manages bookings in the dashboard.
8. Admin signs in to maintain sample train and reservation data.

## Test cases
| Test | Expected result |
|---|---|
| Search a matching route | Matching sample trains appear |
| Choose identical origin and destination | Validation message appears |
| Log in with demo passenger account | Passenger dashboard opens |
| Complete demo booking | PNR and ticket are generated |
| Enter generated PNR | Booking status is displayed |
| Print ticket | Browser print dialog opens |
| Cancel a booking | Status changes to Cancelled and sample refund is recorded |
| Admin adds a train | New service is saved in local browser storage |
| Resize browser to mobile | Layout adapts to a narrow screen |

## Conclusion
RailNova demonstrates the main user interface and workflow of an online train reservation system. Real-world deployment would require a secure backend, database, authorized railway data integration, actual payment processing and notification services.
