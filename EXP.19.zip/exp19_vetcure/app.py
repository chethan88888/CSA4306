"""VetCure - tele-veterinary portal: farmers send animal symptoms to doctors (Flask + SQLite)."""
import os

from flask import Flask, render_template, request, redirect, url_for, flash, session, abort
from werkzeug.security import generate_password_hash, check_password_hash

from common import (setup, query, execute, login_required, start_session, save_upload,
                    IMG_EXT, MEDIA_EXT)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-change-me")

ANIMALS = ["Cow", "Buffalo", "Goat", "Sheep", "Poultry", "Dog", "Cat", "Horse", "Other"]


def seed(db):
    if db.execute("SELECT 1 FROM users").fetchone():
        return
    pw = generate_password_hash("doctor123")
    db.execute("INSERT INTO users(role,name,email,phone,password,area) VALUES('doctor','Dr. Govt Veterinary Hospital','govt@vetcure.test','0400111222',?,'Erode')", (pw,))
    db.execute("INSERT INTO doctors(user_id,type,clinic,specialization,fee) VALUES(1,'govt','Govt. Civil Veterinary Hospital','Large animals',0)")
    db.execute("INSERT INTO users(role,name,email,phone,password,area) VALUES('doctor','Dr. Priya Raman','vet@vetcure.test','0400333444',?,'Erode')", (pw,))
    db.execute("""INSERT INTO doctors(user_id,type,clinic,specialization,fee,bank_name,account_title,account_no,easypaisa_no)
                  VALUES(2,'private','Raman Pet & Livestock Clinic','Dairy cattle & pets',500,'Demo Bank','Priya Raman','1234567890','03001234567')""")
    db.execute("INSERT INTO users(role,name,email,phone,password,area) VALUES('farmer','Demo Farmer','farmer@vetcure.test','9876543210',?,'Erode')", (generate_password_hash("farmer123"),))
    db.execute("INSERT INTO subscriptions(farmer_id,doctor_id,status,method) VALUES(3,1,'active','free')")
    db.executemany("INSERT INTO cures(doctor_id,animal,disease,symptoms,prescription) VALUES(1,?,?,?,?)", [
        ("Cow", "Foot and Mouth Disease", "Fever, blisters on mouth and hooves, drooling, lameness.", "Isolate the animal, wash lesions with mild antiseptic, give soft feed and consult the doctor for supportive treatment. Vaccinate herd every 6 months."),
        ("Cow", "Mastitis", "Swollen painful udder, clotted or watery milk, fever.", "Strip the affected quarter frequently, apply warm compress, antibiotic course as prescribed by the doctor; maintain milking hygiene."),
        ("Poultry", "Newcastle Disease", "Twisted neck, greenish diarrhoea, sudden deaths.", "No curative treatment; isolate sick birds, maintain biosecurity and vaccinate (Lasota) on schedule.")])
    db.execute("INSERT INTO news(doctor_id,title,body) VALUES(1,'Free FMD vaccination camp','Free foot-and-mouth disease vaccination for cattle and buffalo at the hospital every Saturday this month.')")
    db.execute("INSERT INTO complaints(farmer_id,doctor_id,animal,symptoms,status,disease) VALUES(3,1,'Cow','Blisters on hooves','Answered','Foot and Mouth Disease')")
    db.execute("INSERT INTO solutions(complaint_id,doctor_id,diagnosis,prescription,advice) VALUES(1,1,'Suspected FMD','Antiseptic wash, soft feed','Isolate the animal')")


setup(app, seed)


@app.context_processor
def inject():
    role = session.get("role")
    nav = [("index", "Home")]
    if role == "farmer":
        nav += [("doctors", "View Doctors"), ("new_complaint", "Post Complaint"), ("my_complaints", "My Complaint Status"),
                ("cures", "Vetcure Details"), ("news", "News"), ("report", "Report"), ("payments", "Make Payment"), ("profile", "My Profile")]
    elif role == "doctor":
        nav += [("doctor_home", "Dashboard"), ("doctor_complaints", "Complaints"), ("doctor_cures", "Manage Cure"),
                ("doctor_news", "Manage News"), ("doctor_farmers", "Users"), ("doctor_payments", "Payments"),
                ("doctor_feedback", "Feedback"), ("report", "Report"), ("profile", "My Profile")]
    nav.append(("logout", "Logout (%s)" % session["name"]) if role else ("login", "Login"))
    if not role:
        nav.append(("register", "Register"))
    return dict(brand="VetCure", accent="#b45309", nav=nav)


def active_sub(farmer_id, doctor_id):
    return query("SELECT * FROM subscriptions WHERE farmer_id=? AND doctor_id=? AND status='active'", (farmer_id, doctor_id), one=True)


# -------------------------------------------------------------------- auth
@app.route("/")
def index():
    stats = {"doctors": query("SELECT COUNT(*) c FROM doctors", one=True)["c"],
             "farmers": query("SELECT COUNT(*) c FROM users WHERE role='farmer'", one=True)["c"],
             "answered": query("SELECT COUNT(*) c FROM complaints WHERE status='Answered'", one=True)["c"]}
    return render_template("index.html", stats=stats, news=query("SELECT n.*, u.name doctor FROM news n JOIN users u ON u.id=n.doctor_id ORDER BY n.id DESC LIMIT 3"))


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        f = request.form
        role = "doctor" if f.get("role") == "doctor" else "farmer"
        email = f["email"].strip().lower()
        dtype = f.get("dtype", "private")
        if len(f["password"]) < 6:
            flash("Password must be at least 6 characters.", "error")
        elif query("SELECT 1 FROM users WHERE email=?", (email,), one=True):
            flash("E-mail already registered.", "error")
        elif role == "doctor" and dtype == "private" and not ((f.get("account_no") and f.get("bank_name")) or f.get("easypaisa_no")):
            flash("Private doctors must provide bank details and/or an Easypaisa number for payments.", "error")
        else:
            uid = execute("INSERT INTO users(role,name,email,phone,password,area) VALUES(?,?,?,?,?,?)",
                          (role, f["name"].strip(), email, f["phone"].strip(), generate_password_hash(f["password"]), f.get("area", "").strip()))
            if role == "doctor":
                execute("INSERT INTO doctors(user_id,type,clinic,specialization,fee,bank_name,account_title,account_no,easypaisa_no) VALUES(?,?,?,?,?,?,?,?,?)",
                        (uid, dtype if dtype in ("govt", "private") else "private", f.get("clinic", "").strip(), f.get("specialization", "").strip(),
                         (f.get("fee", type=float) or 0) if dtype == "private" else 0, f.get("bank_name", "").strip(), f.get("account_title", "").strip(),
                         f.get("account_no", "").strip(), f.get("easypaisa_no", "").strip()))
            flash("Registration successful. Please log in.", "success")
            return redirect(url_for("login"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = query("SELECT * FROM users WHERE email=?", (request.form["email"].strip().lower(),), one=True)
        if u and check_password_hash(u["password"], request.form["password"]):
            start_session(u)
            return redirect(url_for("doctor_home" if u["role"] == "doctor" else "doctors"))
        flash("Invalid e-mail or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))


@app.route("/profile", methods=["GET", "POST"])
@login_required()
def profile():
    uid = session["uid"]
    if request.method == "POST":
        f = request.form
        execute("UPDATE users SET name=?, phone=?, area=? WHERE id=?", (f["name"].strip(), f["phone"].strip(), f.get("area", "").strip(), uid))
        if session["role"] == "doctor":
            d = query("SELECT * FROM doctors WHERE user_id=?", (uid,), one=True)
            fee = f.get("fee", type=float) if d["type"] == "private" else 0
            execute("UPDATE doctors SET clinic=?, specialization=?, fee=?, bank_name=?, account_title=?, account_no=?, easypaisa_no=? WHERE user_id=?",
                    (f.get("clinic", ""), f.get("specialization", ""), fee or 0, f.get("bank_name", ""), f.get("account_title", ""), f.get("account_no", ""), f.get("easypaisa_no", ""), uid))
        session["name"] = f["name"].strip()
        flash("Profile updated.", "success")
        return redirect(url_for("profile"))
    return render_template("profile.html", me=query("SELECT * FROM users WHERE id=?", (uid,), one=True),
                           d=query("SELECT * FROM doctors WHERE user_id=?", (uid,), one=True))


# ------------------------------------------------------------------ farmer
@app.route("/doctors")
@login_required("farmer")
def doctors():
    kind = request.args.get("type", "")
    rows = query("""SELECT u.id, u.name, u.area, d.*, s.status sub_status,
                    (SELECT ROUND(AVG(rating),1) FROM feedback WHERE doctor_id=u.id) rating
                    FROM doctors d JOIN users u ON u.id=d.user_id LEFT JOIN subscriptions s ON s.doctor_id=u.id AND s.farmer_id=?
                    WHERE (?='' OR d.type=?) ORDER BY d.type, u.name""", (session["uid"], kind, kind))
    return render_template("doctors.html", rows=rows, kind=kind)


@app.route("/subscribe/<int:did>", methods=["GET", "POST"])
@login_required("farmer")
def subscribe(did):
    d = query("SELECT u.id, u.name, d.* FROM doctors d JOIN users u ON u.id=d.user_id WHERE d.user_id=?", (did,), one=True)
    if not d:
        abort(404)
    s = query("SELECT * FROM subscriptions WHERE farmer_id=? AND doctor_id=?", (session["uid"], did), one=True)
    if s and s["status"] in ("active", "pending"):
        flash("You already have a %s subscription with this doctor." % s["status"], "info")
        return redirect(url_for("payments"))
    if request.method == "POST":
        if d["type"] == "govt":
            status, method, ref, amount = "active", "free", None, 0
        else:
            method, ref = request.form.get("method"), request.form.get("reference", "").strip()
            if method not in ("bank", "easypaisa") or len(ref) < 4:
                flash("Choose a payment method and enter the transaction reference.", "error")
                return render_template("subscribe.html", d=d)
            if (method == "bank" and not d["account_no"]) or (method == "easypaisa" and not d["easypaisa_no"]):
                flash("This doctor does not accept that payment method.", "error")
                return render_template("subscribe.html", d=d)
            status, amount = "pending", d["fee"]
        if s:
            execute("UPDATE subscriptions SET status=?, method=?, reference=?, amount=?, created=CURRENT_TIMESTAMP WHERE id=?", (status, method, ref, amount, s["id"]))
        else:
            execute("INSERT INTO subscriptions(farmer_id,doctor_id,status,method,reference,amount) VALUES(?,?,?,?,?,?)", (session["uid"], did, status, method, ref, amount))
        flash("Subscribed (free)." if status == "active" else "Payment submitted - the doctor will verify it and activate your subscription.", "success")
        return redirect(url_for("payments"))
    return render_template("subscribe.html", d=d)


@app.route("/payments")
@login_required("farmer")
def payments():
    rows = query("""SELECT s.*, u.name doctor, d.type FROM subscriptions s JOIN users u ON u.id=s.doctor_id JOIN doctors d ON d.user_id=u.id
                    WHERE s.farmer_id=? ORDER BY s.id DESC""", (session["uid"],))
    return render_template("payments.html", rows=rows)


@app.route("/complaint/new", methods=["GET", "POST"])
@login_required("farmer")
def new_complaint():
    docs = query("""SELECT u.id, u.name, d.type FROM subscriptions s JOIN users u ON u.id=s.doctor_id JOIN doctors d ON d.user_id=u.id
                    WHERE s.farmer_id=? AND s.status='active'""", (session["uid"],))
    if request.method == "POST":
        did = request.form.get("doctor_id", type=int)
        if not active_sub(session["uid"], did):
            flash("Subscribe to this doctor first.", "error")
            return redirect(url_for("doctors"))
        symptoms = request.form.get("symptoms", "").strip()
        media = save_upload(request.files.get("media"), MEDIA_EXT)
        if not symptoms and not media:
            flash("Describe the symptoms or attach a photo / audio / video.", "error")
        else:
            cid = execute("INSERT INTO complaints(farmer_id,doctor_id,animal,symptoms,media) VALUES(?,?,?,?,?)",
                          (session["uid"], did, request.form["animal"], symptoms, media))
            flash("Complaint #%d sent to the doctor." % cid, "success")
            return redirect(url_for("complaint_view", cid=cid))
    return render_template("complaint_form.html", docs=docs, animals=ANIMALS, sel=request.args.get("doctor", type=int))


@app.route("/complaints")
@login_required("farmer")
def my_complaints():
    rows = query("SELECT c.*, u.name doctor FROM complaints c JOIN users u ON u.id=c.doctor_id WHERE c.farmer_id=? ORDER BY c.id DESC", (session["uid"],))
    return render_template("complaints.html", rows=rows, doctor_view=False)


@app.route("/complaint/<int:cid>")
@login_required()
def complaint_view(cid):
    c = query("""SELECT c.*, f.name farmer, f.phone fphone, f.area, d.name doctor FROM complaints c JOIN users f ON f.id=c.farmer_id
                 JOIN users d ON d.id=c.doctor_id WHERE c.id=?""", (cid,), one=True)
    if not c or session["uid"] not in (c["farmer_id"], c["doctor_id"]):
        abort(404)
    sols = query("SELECT * FROM solutions WHERE complaint_id=? ORDER BY id", (cid,))
    fb = query("SELECT 1 FROM feedback WHERE farmer_id=? AND doctor_id=?", (c["farmer_id"], c["doctor_id"]), one=True)
    return render_template("complaint_view.html", c=c, sols=sols, fb=fb)


@app.route("/feedback/<int:did>", methods=["POST"])
@login_required("farmer")
def post_feedback(did):
    if not query("SELECT 1 FROM subscriptions WHERE farmer_id=? AND doctor_id=?", (session["uid"], did), one=True):
        abort(403)
    execute("INSERT INTO feedback(farmer_id,doctor_id,rating,comment) VALUES(?,?,?,?)",
            (session["uid"], did, max(1, min(5, request.form.get("rating", 5, type=int))), request.form.get("comment", "").strip()))
    flash("Thank you for your feedback.", "success")
    return redirect(request.referrer or url_for("doctors"))


@app.route("/cures")
@login_required()
def cures():
    q = request.args.get("q", "").strip()
    rows = query("""SELECT c.*, u.name doctor FROM cures c JOIN users u ON u.id=c.doctor_id
                    WHERE (?='' OR c.disease LIKE ? OR c.animal LIKE ? OR c.symptoms LIKE ?) ORDER BY c.disease""", (q, "%" + q + "%", "%" + q + "%", "%" + q + "%"))
    return render_template("cures.html", rows=rows, q=q)


@app.route("/news")
@login_required()
def news():
    return render_template("news.html", rows=query("SELECT n.*, u.name doctor FROM news n JOIN users u ON u.id=n.doctor_id ORDER BY n.id DESC"))


@app.route("/report")
@login_required()
def report():
    """Disease analysis from recorded complaints: which disease occurs most in each area."""
    area = request.args.get("area", "").strip()
    rows = query("""SELECT COALESCE(NULLIF(f.area,''),'Unknown') area, c.disease, COUNT(*) n FROM complaints c JOIN users f ON f.id=c.farmer_id
                    WHERE c.disease IS NOT NULL AND c.disease!='' AND (?='' OR lower(f.area)=lower(?))
                    GROUP BY 1, 2 ORDER BY 1, n DESC""", (area, area))
    by_area = {}
    for r in rows:
        by_area.setdefault(r["area"], []).append(r)
    areas = [r["a"] for r in query("SELECT DISTINCT COALESCE(NULLIF(area,''),'Unknown') a FROM users WHERE role='farmer' ORDER BY a")]
    by_animal = query("SELECT animal, COUNT(*) n FROM complaints GROUP BY animal ORDER BY n DESC")
    return render_template("report.html", by_area=by_area, areas=areas, area=area, by_animal=by_animal)


# ------------------------------------------------------------------ doctor
@app.route("/doctor")
@login_required("doctor")
def doctor_home():
    uid = session["uid"]
    s = {"open": query("SELECT COUNT(*) c FROM complaints WHERE doctor_id=? AND status='Open'", (uid,), one=True)["c"],
         "farmers": query("SELECT COUNT(*) c FROM subscriptions WHERE doctor_id=? AND status='active'", (uid,), one=True)["c"],
         "pending": query("SELECT COUNT(*) c FROM subscriptions WHERE doctor_id=? AND status='pending'", (uid,), one=True)["c"],
         "rating": query("SELECT ROUND(AVG(rating),1) r FROM feedback WHERE doctor_id=?", (uid,), one=True)["r"]}
    return render_template("doctor_home.html", s=s)


@app.route("/doctor/complaints")
@login_required("doctor")
def doctor_complaints():
    st = request.args.get("status", "")
    rows = query("""SELECT c.*, u.name farmer, u.area FROM complaints c JOIN users u ON u.id=c.farmer_id WHERE c.doctor_id=? AND (?='' OR c.status=?) ORDER BY c.id DESC""",
                 (session["uid"], st, st))
    return render_template("complaints.html", rows=rows, doctor_view=True, st=st)


@app.route("/doctor/complaint/<int:cid>/solution", methods=["POST"])
@login_required("doctor")
def post_solution(cid):
    c = query("SELECT * FROM complaints WHERE id=? AND doctor_id=?", (cid, session["uid"]), one=True)
    if not c:
        abort(404)
    f = request.form
    diagnosis = f["diagnosis"].strip()
    if not diagnosis:
        flash("Diagnosis / disease name is required.", "error")
    else:
        execute("INSERT INTO solutions(complaint_id,doctor_id,diagnosis,prescription,advice) VALUES(?,?,?,?,?)",
                (cid, session["uid"], diagnosis, f.get("prescription", "").strip(), f.get("advice", "").strip()))
        execute("UPDATE complaints SET status='Answered', disease=? WHERE id=?", (diagnosis, cid))
        flash("Solution posted.", "success")
    return redirect(url_for("complaint_view", cid=cid))


@app.route("/doctor/cures", methods=["GET", "POST"])
@login_required("doctor")
def doctor_cures():
    if request.method == "POST":
        f = request.form
        img = save_upload(request.files.get("image"), IMG_EXT)
        execute("INSERT INTO cures(doctor_id,animal,disease,symptoms,prescription,image) VALUES(?,?,?,?,?,?)",
                (session["uid"], f["animal"], f["disease"].strip(), f["symptoms"].strip(), f["prescription"].strip(), img))
        flash("Cure information added.", "success")
        return redirect(url_for("doctor_cures"))
    return render_template("doctor_cures.html", rows=query("SELECT * FROM cures WHERE doctor_id=? ORDER BY id DESC", (session["uid"],)), animals=ANIMALS)


@app.route("/doctor/cures/<int:cid>/delete", methods=["POST"])
@login_required("doctor")
def delete_cure(cid):
    execute("DELETE FROM cures WHERE id=? AND doctor_id=?", (cid, session["uid"]))
    return redirect(url_for("doctor_cures"))


@app.route("/doctor/news", methods=["GET", "POST"])
@login_required("doctor")
def doctor_news():
    if request.method == "POST":
        execute("INSERT INTO news(doctor_id,title,body) VALUES(?,?,?)", (session["uid"], request.form["title"].strip(), request.form["body"].strip()))
        flash("News published.", "success")
        return redirect(url_for("doctor_news"))
    return render_template("doctor_news.html", rows=query("SELECT * FROM news WHERE doctor_id=? ORDER BY id DESC", (session["uid"],)))


@app.route("/doctor/news/<int:nid>/delete", methods=["POST"])
@login_required("doctor")
def delete_news(nid):
    execute("DELETE FROM news WHERE id=? AND doctor_id=?", (nid, session["uid"]))
    return redirect(url_for("doctor_news"))


@app.route("/doctor/farmers")
@login_required("doctor")
def doctor_farmers():
    rows = query("""SELECT u.*, s.status, s.created since, (SELECT COUNT(*) FROM complaints WHERE farmer_id=u.id AND doctor_id=?) n FROM subscriptions s
                    JOIN users u ON u.id=s.farmer_id WHERE s.doctor_id=? ORDER BY u.name""", (session["uid"], session["uid"]))
    return render_template("doctor_farmers.html", rows=rows)


@app.route("/doctor/payments", methods=["GET", "POST"])
@login_required("doctor")
def doctor_payments():
    if request.method == "POST":
        sid, act = request.form.get("sid", type=int), request.form.get("action")
        s = query("SELECT * FROM subscriptions WHERE id=? AND doctor_id=?", (sid, session["uid"]), one=True)
        if s and act in ("approve", "reject"):
            execute("UPDATE subscriptions SET status=? WHERE id=?", ("active" if act == "approve" else "rejected", sid))
            flash("Payment %s." % ("verified - farmer subscribed" if act == "approve" else "rejected"), "success")
        return redirect(url_for("doctor_payments"))
    rows = query("SELECT s.*, u.name farmer, u.phone FROM subscriptions s JOIN users u ON u.id=s.farmer_id WHERE s.doctor_id=? ORDER BY s.id DESC", (session["uid"],))
    total = sum(r["amount"] for r in rows if r["status"] == "active")
    return render_template("doctor_payments.html", rows=rows, total=total)


@app.route("/doctor/feedback")
@login_required("doctor")
def doctor_feedback():
    rows = query("SELECT f.*, u.name farmer FROM feedback f JOIN users u ON u.id=f.farmer_id WHERE f.doctor_id=? ORDER BY f.id DESC", (session["uid"],))
    return render_template("doctor_feedback.html", rows=rows)


if __name__ == "__main__":
    app.run(debug=os.environ.get("DEBUG") == "1", port=int(os.environ.get("PORT", 5000)))
