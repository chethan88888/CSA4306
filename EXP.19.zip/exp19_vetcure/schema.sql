CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  role TEXT NOT NULL CHECK(role IN ('farmer','doctor')),
  name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, phone TEXT,
  password TEXT NOT NULL,
  area TEXT,                                   -- village / town / district (used by the disease report)
  created TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS doctors(
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK(type IN ('govt','private')),   -- govt = Govt. CVH (free), private = paid clinic
  clinic TEXT, specialization TEXT,
  fee REAL NOT NULL DEFAULT 0,
  bank_name TEXT, account_title TEXT, account_no TEXT,
  easypaisa_no TEXT
);
CREATE TABLE IF NOT EXISTS subscriptions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  farmer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  doctor_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','pending','rejected')),
  method TEXT,                 -- free / bank / easypaisa
  reference TEXT,              -- transaction id entered by the farmer
  amount REAL NOT NULL DEFAULT 0,
  created TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(farmer_id, doctor_id)
);
CREATE TABLE IF NOT EXISTS complaints(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  farmer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  doctor_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  animal TEXT NOT NULL, symptoms TEXT,
  media TEXT,                  -- video / audio / image file
  status TEXT NOT NULL DEFAULT 'Open',      -- Open, Answered
  disease TEXT,                -- set by the doctor with the solution; drives the area report
  created TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS solutions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  complaint_id INTEGER NOT NULL REFERENCES complaints(id) ON DELETE CASCADE,
  doctor_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  diagnosis TEXT, prescription TEXT, advice TEXT,
  created TEXT DEFAULT CURRENT_TIMESTAMP
);
-- "Vetcure": affected-animal images with common diseases and prescriptions
CREATE TABLE IF NOT EXISTS cures(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  doctor_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  animal TEXT, disease TEXT NOT NULL, symptoms TEXT, prescription TEXT, image TEXT,
  created TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS news(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  doctor_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL, body TEXT NOT NULL,
  created TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS feedback(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  farmer_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  doctor_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  rating INTEGER NOT NULL, comment TEXT,
  created TEXT DEFAULT CURRENT_TIMESTAMP
);
