# Experiment 19 - VetCure (Tele-Veterinary Portal)

Flask + SQLite web application where **farmers** send animal symptoms (text, image, audio or video) to **doctors**
(Govt. CVH = free, private clinics = paid subscription).

## Run
```bash
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py                                         # http://127.0.0.1:5000
```
`app.db` is created automatically from `schema.sql` with demo data.

## Demo accounts
| Role                   | E-mail              | Password  |
|------------------------|---------------------|-----------|
| Farmer                 | farmer@vetcure.test | farmer123 |
| Doctor (Govt. CVH)     | govt@vetcure.test   | doctor123 |
| Doctor (private, ₹500) | vet@vetcure.test    | doctor123 |

## Features (mapped to the lab sheet)
**User (farmer):** register, login, **subscribe** (free for Govt. CVH; private doctors need a fee), **make payment** via
**bank transfer** or **Easypaisa** (doctor's account details are shown; farmer enters the transaction reference, doctor verifies),
post complaint with text / photo / audio / video, my complaint status, view doctor's solution, view Vetcure details
(diseases with animal images and prescriptions, searchable), view news, view doctors, **view report**, post feedback, my profile.

**Doctor:** register (provides bank and/or Easypaisa details), login, view complaints, post solution (diagnosis, prescription,
advice), manage cure (disease + image + prescription), manage news, view user details, view payment details (verify/reject),
feedback details, report.

**Analysis report:** the diagnosis a doctor enters is stored on the complaint; the report groups cases by farmer **area** and
disease to show which disease occurs most in each area.

## Notes
- A farmer can post a complaint only to doctors with an **active** subscription.
- In a real deployment, Govt. CVH doctor accounts should be verified/approved by an administrator.
- Payment verification is manual (doctor confirms the reference); integrate a real gateway API if required.

## Structure
`app.py` - `common.py` - `schema.sql` (users, doctors, subscriptions, complaints, solutions, cures, news, feedback) - `templates/` - `static/`
