# ReNewMarket — Internet Programming Lab

## Setup (Windows, no terminal needed)
1. Install XAMPP and start **Apache** and **MySQL**.
2. Copy the `14_ReNewMarket` folder into `C:\xampp\htdocs\`.
3. Open `http://localhost/phpmyadmin`, choose **Import**, select `database.sql`, then click **Go**.
4. Visit `http://localhost/14_ReNewMarket/create_admin.php` once.
5. Login at `http://localhost/14_ReNewMarket/login.php`:
   - Email: `admin@demo.com`
   - Password: `Admin@123`
6. Delete `create_admin.php` after admin creation.
7. Register a normal user from the site.

## Database
Database name: `renewmarket_db`. XAMPP defaults in `db.php` are MySQL user `root` and blank password.

## Files
- `index.php`: homepage
- `login.php`, `register.php`, `logout.php`: account flow
- `dashboard.php`: core experiment functionality
- `db.php`: PDO connection and session helpers
- `database.sql`: database schema and sample data
- `style.css`: responsive design
- `create_admin.php`: one-time admin setup

## Notes
This is an academic local demo. Checkout/wallet operations are simulations, SMS is not connected to a provider, and any QR rendering needs an external service if added. Do not use real payment details. Before production deployment, add CSRF protection, HTTPS, stronger authorization checks, and provider integrations.
