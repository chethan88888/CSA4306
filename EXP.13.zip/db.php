<?php
if(session_status()===PHP_SESSION_NONE)session_start();
try{$pdo=new PDO('mysql:host=localhost;dbname=blossomgifts_db;charset=utf8mb4','root','',[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);}
catch(PDOException $e){exit('Database connection failed. Start MySQL and import database.sql. '.htmlspecialchars($e->getMessage()));}
function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function logged_in(){return isset($_SESSION['user']);}
function require_login(){if(!logged_in()){header('Location: login.php');exit;}}
function is_admin(){return logged_in()&&$_SESSION['user']['role']==='admin';}
function require_admin(){require_login();if(!is_admin()){http_response_code(403);exit('Admin access required');}}
function flash($m,$type='success'){$_SESSION['flash']=[$m,$type];}
function show_flash(){if(isset($_SESSION['flash'])){[$m,$t]=$_SESSION['flash'];echo '<div class="notice '.($t==='error'?'error':'').'">'.e($m).'</div>';unset($_SESSION['flash']);}}
?>