<?php
function page_header(string $title, bool $admin=false, string $active=''): void {
    $base = $admin ? '../' : '';
    $name = $admin ? ($_SESSION['admin_name'] ?? 'Administrator') : ($_SESSION['user_name'] ?? 'Guest');
    ?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($title)?> · Luma Library</title>
<link rel="stylesheet" href="<?=$base?>style.css">
<script defer src="<?=$base?>script.js"></script>
</head>
<body class="<?= $admin ? 'admin-shell' : 'student-shell' ?>">
<?php if($admin): ?>
<aside class="sidebar">
  <a class="logo" href="dashboard.php"><span class="logo-mark">L</span><span>LUMA<span>LIBRARY</span></span></a>
  <div class="side-label">CONTROL CENTER</div>
  <nav class="side-nav">
    <a class="<?= $active==='dashboard'?'active':'' ?>" href="dashboard.php"><span>⌂</span> Overview</a>
    <a class="<?= $active==='books'?'active':'' ?>" href="books.php"><span>▤</span> Collection</a>
    <a class="<?= $active==='issues'?'active':'' ?>" href="issues.php"><span>↔</span> Circulation</a>
    <a class="<?= $active==='students'?'active':'' ?>" href="students.php"><span>♙</span> Members</a>
  </nav>
  <div class="side-bottom">
    <div class="profile-mini"><div class="avatar">A</div><div><b><?=e($name)?></b><small>Library Admin</small></div></div>
    <a class="logout-link" href="../logout.php">↪ Sign out</a>
  </div>
</aside>
<main class="admin-main">
  <header class="admin-top"><div><div class="eyebrow">LIBRARY OPERATIONS</div><h1><?=e($title)?></h1></div><a class="user-chip" href="../index.php">View student site ↗</a></header>
<?php else: ?>
<header class="topbar">
  <a class="brand" href="index.php"><span class="brand-mark">L</span><span>Luma Library</span></a>
  <nav>
    <a class="<?= $active==='home'?'active':'' ?>" href="index.php">Home</a>
    <a class="<?= $active==='books'?'active':'' ?>" href="books.php">Discover</a>
    <?php if(!empty($_SESSION['user_id'])): ?><a class="<?= $active==='mybooks'?'active':'' ?>" href="my_books.php">My shelf</a><a href="logout.php">Sign out</a><?php else: ?><a href="login.php">Sign in</a><a class="nav-cta" href="register.php">Join library</a><?php endif; ?>
  </nav>
</header>
<main class="site-main">
<?php endif; }
function page_footer(bool $admin=false): void { if($admin){ echo '</main></body></html>'; return; } echo '</main><footer><b>Luma Library</b><span>·</span><span>Read more. Discover more.</span><a href="contact.php">Contact</a><a href="admin/login.php">Staff portal</a></footer></body></html>'; }
function status_badge(string $status): string { $cls=strtolower($status); return '<span class="status '.$cls.'">'.e($status).'</span>'; }
?>
