CREATE DATABASE IF NOT EXISTS `easytoll_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `easytoll_db`;
CREATE TABLE users(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100),email VARCHAR(150) UNIQUE,phone VARCHAR(30),password_hash VARCHAR(255),role VARCHAR(30) DEFAULT 'driver');
CREATE TABLE vehicles(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT,registration_no VARCHAR(30) UNIQUE,vehicle_type VARCHAR(50),FOREIGN KEY(user_id) REFERENCES users(id));
CREATE TABLE toll_gates(id INT AUTO_INCREMENT PRIMARY KEY,gate_name VARCHAR(150),location VARCHAR(150),one_way_fee DECIMAL(8,2),active TINYINT DEFAULT 1);
CREATE TABLE wallets(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT UNIQUE,balance DECIMAL(10,2) DEFAULT 0,FOREIGN KEY(user_id) REFERENCES users(id));
CREATE TABLE toll_passes(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT,vehicle_id INT,pass_type VARCHAR(50),start_date DATE,end_date DATE,status VARCHAR(30) DEFAULT 'Pending',qr_token VARCHAR(100) UNIQUE,FOREIGN KEY(user_id) REFERENCES users(id),FOREIGN KEY(vehicle_id) REFERENCES vehicles(id));
CREATE TABLE toll_tickets(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT,gate_id INT,ticket_code VARCHAR(100) UNIQUE,amount DECIMAL(8,2),status VARCHAR(30) DEFAULT 'Purchased',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id),FOREIGN KEY(gate_id) REFERENCES toll_gates(id));
INSERT INTO toll_gates(gate_name,location,one_way_fee) VALUES('Erode North Toll','Erode, Tamil Nadu',75),('Coimbatore Highway Toll','Coimbatore, Tamil Nadu',110),('Salem Bypass Toll','Salem, Tamil Nadu',95);