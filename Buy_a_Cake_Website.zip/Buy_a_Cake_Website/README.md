# Buy a Cake — Internet Programming Lab Experiment

A responsive front-end demonstration of an online cake ordering portal with Student/Customer and Admin workflows.

## Features

### Student / Customer
- Register and log in (demo browser-based account storage)
- Search cakes by name and description
- Filter by category, flavor, and maximum price
- Browse cake cards with description, image/emoji, and price
- Add cakes to cart and change quantities
- Place orders with shipping address, phone, delivery date, gift message, and payment-method selection
- View order history and delivery/shipping status

### Admin
- Demo admin login
- Add, edit, and delete cake products
- Set category, flavor, price, description, and optional image URL
- View orders and update status: Order Placed, Confirmed, Preparing, Shipped, Out for Delivery, Delivered, Cancelled

## Run the project

1. Extract `Buy_a_Cake_Website.zip`.
2. Open the extracted folder.
3. Double-click `index.html`, or open the folder in VS Code and use the Live Server extension.
4. Open **Admin** and sign in using:
   - Email: `admin@buyacake.test`
   - Password: `admin123`

## Important demo limitations

- This is a static HTML/CSS/JavaScript lab project. Data is saved in the browser's `localStorage`.
- Accounts/passwords are not securely stored. Do not use real passwords or personal information.
- Checkout records a demo order only. No real payment is processed, no email is sent, and delivery tracking is simulated by the admin changing the order status.
- For a production system, add a backend/database, hashed passwords, server-side authorization, transactional email, and a real payment provider such as Razorpay/Stripe with server-side verification.
- Cake images use emoji illustrations by default; the admin can enter an image URL for a product.

## Project files

- `index.html` — page layout and forms
- `style.css` — responsive design and styling
- `app.js` — catalogue, cart, registration/login demo, checkout, orders, and admin logic
