const initialCakes = [
 {id:1,name:"Chocolate Truffle",category:"Chocolate",flavor:"Chocolate",price:650,description:"Rich chocolate sponge layered with silky truffle ganache.",emoji:"🍫",tag:"BESTSELLER"},
 {id:2,name:"Strawberry Dream",category:"Fruit",flavor:"Strawberry",price:720,description:"Soft vanilla sponge with fresh strawberry cream.",emoji:"🍓",tag:"FRESH PICK"},
 {id:3,name:"Classic Vanilla",category:"Birthday",flavor:"Vanilla",price:500,description:"A timeless vanilla cake with smooth whipped frosting.",emoji:"🍰",tag:"CLASSIC"},
 {id:4,name:"Red Velvet Love",category:"Special",flavor:"Red Velvet",price:850,description:"Velvety cocoa sponge with a creamy cheese-style frosting.",emoji:"❤️",tag:"POPULAR"},
 {id:5,name:"Black Forest",category:"Birthday",flavor:"Black Forest",price:600,description:"Chocolate layers, cherries, and light cream in every bite.",emoji:"🍒",tag:"FAVOURITE"},
 {id:6,name:"Butterscotch Crunch",category:"Special",flavor:"Butterscotch",price:580,description:"Caramel notes and crunchy praline meet soft sponge.",emoji:"🍮",tag:"CRUNCHY"},
 {id:7,name:"Golden Wedding Cake",category:"Wedding",flavor:"Vanilla",price:1800,description:"Elegant vanilla layers for your most memorable day.",emoji:"🎂",tag:"CELEBRATION"},
 {id:8,name:"Choco Berry Bliss",category:"Chocolate",flavor:"Chocolate",price:950,description:"Chocolate ganache topped with a berry-inspired finish.",emoji:"🫐",tag:"SPECIAL"}
];
const $ = id => document.getElementById(id);
const read = (key, fallback) => { try { const v=localStorage.getItem(key); return v===null?fallback:JSON.parse(v); } catch(e){ return fallback; } };
const save = (key, value) => localStorage.setItem(key, JSON.stringify(value));
let cakes = read("bac_cakes", initialCakes);
let cart = read("bac_cart", []);
let orders = read("bac_orders", []);
let users = read("bac_users", []);
let currentUser = read("bac_currentUser", null);
let adminOn = false;
let toastTimer;
const money = n => "₹" + Number(n).toLocaleString("en-IN");
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function toast(message){$("toast").textContent=message;$("toast").classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>$("toast").classList.remove("show"),2600);}
function showPage(name){
 document.querySelectorAll(".page").forEach(p=>p.classList.add("hidden"));
 const page=$(name+"Page"); if(page)page.classList.remove("hidden");
 document.querySelectorAll(".nav-link").forEach(a=>a.classList.toggle("active",a.dataset.page===name));
 $("mainNav").classList.remove("open");
 if(name==="shop")renderCakes(); if(name==="cart")renderCart(); if(name==="checkout")renderCheckoutSummary(); if(name==="orders")renderOrders(); if(name==="account")renderAccount(); if(name==="admin")renderAdmin();
 window.scrollTo({top:0,behavior:"smooth"});
}
document.querySelectorAll(".nav-link").forEach(a=>a.addEventListener("click",e=>{e.preventDefault();showPage(a.dataset.page)}));
$("menuToggle").addEventListener("click",()=>$("mainNav").classList.toggle("open"));
$("searchInput").addEventListener("input",renderCakes);$("categoryFilter").addEventListener("change",renderCakes);$("flavorFilter").addEventListener("change",renderCakes);
$("priceFilter").addEventListener("input",()=>{$("priceValue").textContent=money($("priceFilter").value);renderCakes()});
function cakeVisual(c){return c.image?`<img src="${esc(c.image)}" alt="${esc(c.name)}" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"><span class="cake-emoji" style="display:none">${c.emoji||"🎂"}</span>`:`<span class="cake-emoji">${c.emoji||"🎂"}</span>`}
function renderCakes(){
 const search=$("searchInput").value.toLowerCase().trim(),cat=$("categoryFilter").value,flavor=$("flavorFilter").value,max=Number($("priceFilter").value);
 const list=cakes.filter(c=>(c.name+" "+c.description+" "+c.flavor).toLowerCase().includes(search)&&(!cat||c.category===cat)&&(!flavor||c.flavor===flavor)&&Number(c.price)<=max);
 $("cakeGrid").innerHTML=list.length?list.map(c=>`<article class="cake-card"><div class="cake-image">${cakeVisual(c)}<span class="cake-tag">${esc(c.tag||c.category)}</span></div><div class="cake-info"><span class="flavor">${esc(c.flavor)} · ${esc(c.category)}</span><h3>${esc(c.name)}</h3><p>${esc(c.description)}</p><div class="cake-card-bottom"><span class="price">${money(c.price)}</span><button class="add-button" aria-label="Add ${esc(c.name)} to cart" onclick="addToCart(${c.id})">+</button></div></div></article>`).join(""):`<div class="empty-filter">No cakes match your filters. Try another search or price range.</div>`;
}
function addToCart(id){const c=cakes.find(x=>x.id===id);if(!c)return;const item=cart.find(x=>x.id===id);if(item)item.qty++;else cart.push({id:c.id,qty:1});save("bac_cart",cart);updateCartCount();toast(c.name+" added to cart");}
function updateCartCount(){$("cartCount").textContent=cart.reduce((sum,x)=>sum+x.qty,0)}
function cartRows(){return cart.map(item=>{const c=cakes.find(x=>x.id===item.id);return c?{...c,qty:item.qty}:null}).filter(Boolean)}
function renderCart(){
 const rows=cartRows(),subtotal=rows.reduce((s,c)=>s+c.price*c.qty,0);
 if(!rows.length){$("cartContent").innerHTML=`<div class="empty-state" style="max-width:600px;margin:0 auto 60px"><span>🛍️</span><h3>Your cart is waiting for something sweet</h3><p>Explore the collection and add your favourite cake.</p><button class="primary-button" onclick="showPage('shop')">Browse cakes →</button></div>`;return}
 $("cartContent").innerHTML=`<div class="cart-layout"><div class="cart-list">${rows.map(c=>`<div class="cart-item"><span class="cart-emoji">${c.emoji||"🎂"}</span><div class="cart-item-main"><h3>${esc(c.name)}</h3><p>${money(c.price)} each</p></div><div class="quantity"><button onclick="changeQty(${c.id},-1)">−</button><span>${c.qty}</span><button onclick="changeQty(${c.id},1)">+</button></div><strong>${money(c.price*c.qty)}</strong></div>`).join("")}</div><aside class="cart-summary"><h3>Order summary</h3><div class="summary-line"><span>Subtotal (${rows.reduce((s,c)=>s+c.qty,0)} items)</span><span>${money(subtotal)}</span></div><div class="summary-line"><span>Delivery</span><span>Free</span></div><div class="summary-line total"><span>Total</span><span>${money(subtotal)}</span></div><button class="primary-button" onclick="showPage('checkout')">Continue to checkout →</button><p class="notice">Delivery dates and address are collected at checkout.</p></aside></div>`;
}
function changeQty(id,delta){const i=cart.find(x=>x.id===id);if(i){i.qty+=delta;if(i.qty<=0)cart=cart.filter(x=>x.id!==id);save("bac_cart",cart);updateCartCount();renderCart()}}
function renderCheckoutSummary(){const rows=cartRows(),total=rows.reduce((s,c)=>s+c.price*c.qty,0);$("checkoutSummary").innerHTML=`<strong>Order total</strong><strong>${money(total)}</strong>`;const date=$('checkoutForm').elements.date;date.min=new Date().toISOString().slice(0,10);}
$("checkoutForm").addEventListener("submit",e=>{e.preventDefault();const rows=cartRows();if(!rows.length){toast("Your cart is empty");showPage("shop");return}const data=Object.fromEntries(new FormData(e.target).entries());const order={id:"CA"+Date.now().toString().slice(-7),items:rows.map(c=>({id:c.id,name:c.name,price:c.price,qty:c.qty,emoji:c.emoji})),total:rows.reduce((s,c)=>s+c.price*c.qty,0),customer:data.name,email:data.email,phone:data.phone,date:data.date,address:data.address,message:data.message,payment:data.payment,status:"Order Placed",created:new Date().toLocaleString()};orders.unshift(order);save("bac_orders",orders);cart=[];save("bac_cart",cart);updateCartCount();e.target.reset();toast("Order placed successfully! Order ID: "+order.id);showPage("orders")});
function renderOrders(){const list=currentUser?orders.filter(o=>o.email.toLowerCase()===currentUser.email.toLowerCase()):orders;const target=$("ordersContent");if(!list.length){target.innerHTML=`<div class="empty-state" style="max-width:620px;margin:0 auto 60px"><span>📦</span><h3>No orders yet</h3><p>${currentUser?"Your placed orders will appear here.":"Showing demo orders from this browser. Register or log in to manage your account."}</p><button class="primary-button" onclick="showPage('shop')">Find a cake →</button></div>`;return}target.innerHTML=`<div class="order-list">${list.map(o=>`<article class="order-card"><div class="cart-emoji">🎂</div><div class="order-main"><h3>Order ${esc(o.id)}</h3><p>${o.items.map(i=>esc(i.name)+" × "+i.qty).join(", ")}</p><div class="order-meta">Placed: ${esc(o.created)}<br>Delivery: ${esc(o.date)} · ${esc(o.address)}<br>Contact: ${esc(o.customer)} (${esc(o.phone)})${o.message?"<br>Message: "+esc(o.message):""}</div></div><div><span class="status-pill">${esc(o.status)}</span><p style="margin-top:12px;font-weight:700">${money(o.total)}</p></div></article>`).join("")}</div>`}
$("registerForm").addEventListener("submit",e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target).entries());if(users.some(u=>u.email.toLowerCase()===d.email.toLowerCase())){toast("An account with this email already exists");return}users.push(d);save("bac_users",users);currentUser={name:d.name,email:d.email};save("bac_currentUser",currentUser);e.target.reset();renderAccount();toast("Registration successful")});
$("loginForm").addEventListener("submit",e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target).entries());const u=users.find(u=>u.email.toLowerCase()===d.email.toLowerCase()&&u.password===d.password);if(!u){toast("Invalid login. Register first or check details.");return}currentUser={name:u.name,email:u.email};save("bac_currentUser",currentUser);renderAccount();toast("Welcome back, "+u.name)});
function renderAccount(){$("accountStatus").innerHTML=currentUser?`<p>Logged in as <b>${esc(currentUser.name)}</b> (${esc(currentUser.email)})</p><button class="secondary-button" onclick="logoutUser()">Logout</button>`:"";if(currentUser){$("loginForm").classList.add("hidden")}else{$("loginForm").classList.remove("hidden")}}
function logoutUser(){currentUser=null;localStorage.removeItem("bac_currentUser");renderAccount();toast("You have logged out")}
$("adminLoginForm").addEventListener("submit",e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target).entries());if(d.email==="admin@buyacake.test"&&d.password==="admin123"){adminOn=true;renderAdmin();toast("Admin dashboard opened")}else toast("Incorrect admin credentials")});
$("adminLogout").addEventListener("click",()=>{adminOn=false;renderAdmin()});
function renderAdmin(){if(!adminOn){$("adminLoginArea").classList.remove("hidden");$("adminDashboard").classList.add("hidden");return}$("adminLoginArea").classList.add("hidden");$("adminDashboard").classList.remove("hidden");renderAdminProducts();renderAdminOrders()}
function renderAdminProducts(){$("adminProducts").innerHTML=cakes.map(c=>`<div class="admin-product-row"><div><strong>${esc(c.name)}</strong><small>${esc(c.category)} · ${money(c.price)}</small></div><div class="mini-actions"><button onclick="editCake(${c.id})">Edit</button><button class="delete" onclick="deleteCake(${c.id})">Delete</button></div></div>`).join("")||"<p class='muted'>No products added.</p>"}
function renderAdminOrders(){$("adminOrders").innerHTML=orders.map(o=>`<div class="admin-order-row"><div><strong>${esc(o.id)} · ${esc(o.customer)}</strong><small>${esc(o.email)} · ${money(o.total)} · ${esc(o.address)}</small></div><div class="mini-actions"><select aria-label="Update order status" onchange="updateOrderStatus('${o.id}',this.value)">${["Order Placed","Confirmed","Preparing","Shipped","Out for Delivery","Delivered","Cancelled"].map(s=>`<option ${o.status===s?"selected":""}>${s}</option>`).join("")}</select></div></div>`).join("")||"<p class='muted'>No orders to manage yet.</p>"}
$("productForm").addEventListener("submit",e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target).entries());const id=d.id?Number(d.id):Date.now();const product={id,name:d.name,category:d.category,flavor:d.flavor,price:Number(d.price),description:d.description,image:d.image,emoji:"🎂",tag:"BAKERY PICK"};if(d.id)cakes=cakes.map(c=>c.id===id?{...c,...product}:c);else cakes.unshift(product);save("bac_cakes",cakes);e.target.reset();$("productForm").elements.id.value="";$("productFormTitle").textContent="Add a cake";$("cancelEdit").classList.add("hidden");renderAdminProducts();renderCakes();toast("Cake saved successfully")});
function editCake(id){const c=cakes.find(c=>c.id===id);if(!c)return;const f=$("productForm");["id","name","category","flavor","price","description","image"].forEach(k=>f.elements[k].value=c[k]??"");$("productFormTitle").textContent="Edit cake";$("cancelEdit").classList.remove("hidden");f.scrollIntoView({behavior:"smooth",block:"start"})}
$("cancelEdit").addEventListener("click",()=>{$("productForm").reset();$("productForm").elements.id.value="";$("productFormTitle").textContent="Add a cake";$("cancelEdit").classList.add("hidden")});
function deleteCake(id){if(!confirm("Delete this cake from the catalogue?"))return;cakes=cakes.filter(c=>c.id!==id);save("bac_cakes",cakes);renderAdminProducts();renderCakes();toast("Cake removed")}
function updateOrderStatus(id,status){orders=orders.map(o=>o.id===id?{...o,status}:o);save("bac_orders",orders);renderAdminOrders();toast("Order status updated")}
updateCartCount();renderCakes();
