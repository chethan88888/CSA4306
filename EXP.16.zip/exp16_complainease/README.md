# Experiment 16 - ComplainEase (Complaint Registration & Management)

Flask + SQLite web application with three roles: **User**, **Officer**, **Admin**.

## Run
```bash
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py                                         # http://127.0.0.1:5000
```
The SQLite database (`app.db`) is created automatically from `schema.sql` on first start, with demo data.

## Demo accounts
| Role    | Login                                          | Password   |
|---------|------------------------------------------------|------------|
| Admin   | admin@complainease.test                        | admin123   |
| Officer | officer@complainease.test  (or ID `OFF-1001`)  | officer123 |
| User    | user@complainease.test                         | user123    |

## Features (mapped to the lab sheet)
**User:** register / login, post complaint (category, description, document upload), **mark location on a map**
(Leaflet + OpenStreetMap - no API key; each complaint also links to Google Maps), view complaint status & history,
add more information/evidence, feedback & rating on closed complaints, admin contact details, search common issues & solutions,
status notifications (e-mail/SMS simulated: printed in the console and shown on the Notifications page).

**Officer:** register / login, view complaints, update status (Pending, Assigned, In Progress, Resolved, Rejected) with a note,
upload **proof of work**.

**Admin:** generate ID & password for officers (and any account), create / delete accounts, view all accounts (including an
officer's complaints), change any password, **hide features** from users/officers, insert common-issue information,
assign complaints to officers, dashboard statistics.

## Structure
```
app.py          routes & business logic
common.py       DB helpers, uploads, role guard
schema.sql      tables: users, complaints, updates, feedback, notifications, features, faq
templates/      Jinja2 pages        static/  CSS + uploaded files
```

## Notes
- Passwords are stored hashed (Werkzeug). Set `SECRET_KEY` in the environment for real use.
- To send real e-mail/SMS, replace the `print` in `notify()` (app.py) with an SMTP / SMS-gateway call.
- To use the Google Maps JavaScript API instead of OpenStreetMap, swap the Leaflet block in `templates/complaint_form.html` (needs an API key).
