"""Shared helpers: SQLite access, uploads, OTP (demo mode), role-based login guard."""
import os
import sqlite3
import functools
import random
import secrets
import time
import uuid

from flask import g, session, redirect, url_for, flash, request, current_app
from werkzeug.utils import secure_filename

IMG_EXT = {"png", "jpg", "jpeg", "gif", "webp"}
DOC_EXT = IMG_EXT | {"pdf", "doc", "docx", "txt"}
MEDIA_EXT = IMG_EXT | {"mp4", "webm", "mov", "mp3", "wav", "ogg", "m4a"}


# ---------------------------------------------------------------- database
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(current_app.config["DB_PATH"])
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db


def close_db(_=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def query(sql, args=(), one=False):
    cur = get_db().execute(sql, args)
    rows = cur.fetchall()
    cur.close()
    if one:
        return rows[0] if rows else None
    return rows


def execute(sql, args=()):
    db = get_db()
    cur = db.execute(sql, args)
    db.commit()
    return cur.lastrowid


def setup(app, seed=None):
    """Create folders, run schema.sql (idempotent) and optional seed(db)."""
    app.config.setdefault("DB_PATH", os.path.join(app.root_path, "app.db"))
    app.config.setdefault("UPLOAD_FOLDER", os.path.join(app.root_path, "static", "uploads"))
    app.config.setdefault("DEMO_MODE", os.environ.get("DEMO_MODE", "1") == "1")
    app.config["MAX_CONTENT_LENGTH"] = 32 * 1024 * 1024
    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)
    app.teardown_appcontext(close_db)
    with app.app_context():
        db = get_db()
        with open(os.path.join(app.root_path, "schema.sql"), encoding="utf-8") as f:
            db.executescript(f.read())
        if seed:
            seed(db)
        db.commit()


# ----------------------------------------------------------------- uploads
def save_upload(file, allowed=DOC_EXT):
    """Save an uploaded FileStorage; return stored file name or None."""
    if not file or not file.filename:
        return None
    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    if allowed and ext not in allowed:
        flash("File type .%s is not allowed." % ext, "error")
        return None
    name = uuid.uuid4().hex[:10] + "_" + secure_filename(file.filename)
    file.save(os.path.join(current_app.config["UPLOAD_FOLDER"], name))
    return name


# --------------------------------------------------------------------- OTP
def send_otp(purpose, target=""):
    """Generate a 6-digit OTP bound to this session. In DEMO_MODE it is shown on screen
    (replace the print/flash with an SMS/e-mail gateway call for production)."""
    code = "%06d" % random.SystemRandom().randrange(0, 1000000)
    session["otp"] = {"code": code, "purpose": purpose, "exp": time.time() + 300, "tries": 0}
    print("[OTP] %s -> %s : %s" % (purpose, target, code))
    if current_app.config.get("DEMO_MODE"):
        flash("DEMO OTP (would be sent by SMS/e-mail): %s" % code, "info")
    return code


def check_otp(code, purpose):
    o = session.get("otp")
    if not o or o["purpose"] != purpose or time.time() > o["exp"] or o["tries"] >= 5:
        return False
    o["tries"] += 1
    session["otp"] = o
    if secrets.compare_digest(o["code"], (code or "").strip()):
        session.pop("otp", None)
        return True
    return False


# -------------------------------------------------------------- auth guard
def login_required(*roles):
    def deco(f):
        @functools.wraps(f)
        def wrapper(*a, **k):
            if "uid" not in session:
                flash("Please log in first.", "error")
                return redirect(url_for("login", next=request.path))
            if roles and session.get("role") not in roles:
                flash("You do not have access to that page.", "error")
                return redirect(url_for("index"))
            return f(*a, **k)
        return wrapper
    return deco


def start_session(user, extra=None):
    session.clear()
    session["uid"] = user["id"]
    session["role"] = user["role"]
    session["name"] = user["name"]
    session.permanent = False
    if extra:
        session.update(extra)
