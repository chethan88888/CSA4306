"""ComplainEase - online complaint registration and management (Flask + SQLite)."""
import os
import secrets
import string

from flask import Flask, render_template, request, redirect, url_for, flash, session, abort
from werkzeug.security import generate_password_hash, check_password_hash

from common import (setup, query, execute, save_upload, login_required, start_session,
                    IMG_EXT, DOC_EXT)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-change-me")

CATEGORIES = ["Water Supply", "Electricity", "Roads & Transport", "Sanitation",
              "Public Safety", "Healthcare", "Other"]
STATUSES = ["Pending", "Assigned", "In Progress", "Resolved", "Rejected"]
FEATURES = [("map", "Location marking on map"), ("feedback", "Feedback / rating"),
            ("contact", "Admin contact details"), ("search", "Common issues search")]


def seed(db):
    if not db.execute("SELECT 1 FROM users").fetchone():
        rows = [("OFF-0001", "Administrator", "admin@complainease.test", "9999999999", "admin123", "admin"),
                ("OFF-1001", "Demo Officer", "officer@complainease.test", "8888888888", "officer123", "officer"),
                (None, "Demo User", "user@complainease.test", "7777777777", "user123", "user")]
        for code, n, e, p, pw, r in rows:
            db.execute("INSERT INTO users(code,name,email,phone,password,role) VALUES(?,?,?,?,?,?)",
                       (code, n, e, p, generate_password_hash(pw), r))
    if not db.execute("SELECT 1 FROM features").fetchone():
        db.executemany("INSERT INTO features(name,label) VALUES(?,?)", FEATURES)
    if not db.execute("SELECT 1 FROM faq").fetchone():
        db.executemany("INSERT INTO faq(category,issue,solution) VALUES(?,?,?)", [
            ("Water Supply", "No water supply in my street", "Check whether a maintenance notice is displayed. If not, post a complaint with your street address and mark the location on the map."),
            ("Electricity", "Frequent power cuts", "Note the times of the outages and attach a photo of your meter board when you post the complaint."),
            ("Roads & Transport", "Pothole on the road", "Mark the exact location on the map and attach a clear photo for faster action."),
            ("Sanitation", "Garbage not collected", "Mention the date of the last pickup and your ward number in the description."),
            ("Public Safety", "Street light not working", "Give the pole number if visible, plus the nearest landmark."),
        ])


setup(app, seed)


# ------------------------------------------------------------------ helpers
def feature_on(name):
    row = query("SELECT visible FROM features WHERE name=?", (name,), one=True)
    return bool(row["visible"]) if row else True


def notify(user_id, message):
    """Simulated e-mail / SMS: stored in DB and printed to the console."""
    execute("INSERT INTO notifications(user_id,message) VALUES(?,?)", (user_id, message))
    u = query("SELECT email,phone FROM users WHERE id=?", (user_id,), one=True)
    if u:
        print("[EMAIL to %s | SMS to %s] %s" % (u["email"], u["phone"], message))


def next_officer_code():
    row = query("SELECT MAX(CAST(SUBSTR(code,5) AS INTEGER)) m FROM users WHERE code LIKE 'OFF-%' AND role='officer'", one=True)
    return "OFF-%d" % ((row["m"] or 1000) + 1)


def can_view(c):
    r = session.get("role")
    return r in ("admin", "officer") or c["user_id"] == session.get("uid")


@app.context_processor
def inject():
    role = session.get("role")
    nav = [("index", "Home")]
    if feature_on("search"):
        nav.append(("search", "Common Issues"))
    if role == "user":
        nav += [("new_complaint", "Post Complaint"), ("my_complaints", "My Complaints"),
                ("notifications", "Notifications")]
        if feature_on("contact"):
            nav.append(("contact", "Admin Contact"))
    elif role == "officer":
        nav += [("officer_home", "Complaints"), ("notifications", "Notifications")]
    elif role == "admin":
        nav += [("admin_home", "Dashboard"), ("admin_users", "Accounts"), ("admin_features", "Features")]
    nav.append(("logout", "Logout (%s)" % session["name"]) if role else ("login", "Login"))
    if not role:
        nav.append(("register", "Register"))
    return dict(brand="ComplainEase", accent="#0f766e", nav=nav, feature_on=feature_on)


# --------------------------------------------------------------------- auth
@app.route("/")
def index():
    stats = {
        "total": query("SELECT COUNT(*) c FROM complaints", one=True)["c"],
        "resolved": query("SELECT COUNT(*) c FROM complaints WHERE status='Resolved'", one=True)["c"],
    }
    return render_template("index.html", stats=stats)


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        f = request.form
        name, email, phone = f["name"].strip(), f["email"].strip().lower(), f["phone"].strip()
        role = f.get("role", "user")
        if role not in ("user", "officer"):
            role = "user"
        if len(f["password"]) < 6:
            flash("Password must be at least 6 characters.", "error")
        elif query("SELECT 1 FROM users WHERE email=?", (email,), one=True):
            flash("That e-mail is already registered.", "error")
        else:
            code = next_officer_code() if role == "officer" else None
            execute("INSERT INTO users(code,name,email,phone,password,role) VALUES(?,?,?,?,?,?)",
                    (code, name, email, phone, generate_password_hash(f["password"]), role))
            flash("Registration successful." + (" Your officer ID is %s." % code if code else "") + " Please log in.", "success")
            return redirect(url_for("login"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        ident = request.form["identifier"].strip()
        u = query("SELECT * FROM users WHERE lower(email)=lower(?) OR code=?", (ident, ident), one=True)
        if u and check_password_hash(u["password"], request.form["password"]):
            start_session(u)
            flash("Welcome, %s!" % u["name"], "success")
            nxt = request.args.get("next")
            if nxt and nxt.startswith("/"):
                return redirect(nxt)
            return redirect(url_for({"user": "my_complaints", "officer": "officer_home", "admin": "admin_home"}[u["role"]]))
        flash("Invalid credentials.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("Logged out.", "info")
    return redirect(url_for("index"))


# --------------------------------------------------------------------- user
@app.route("/complaint/new", methods=["GET", "POST"])
@login_required("user")
def new_complaint():
    if request.method == "POST":
        f = request.form
        att = save_upload(request.files.get("attachment"), DOC_EXT)
        lat = float(f["lat"]) if f.get("lat") else None
        lng = float(f["lng"]) if f.get("lng") else None
        cid = execute(
            "INSERT INTO complaints(user_id,category,title,description,address,lat,lng,attachment) VALUES(?,?,?,?,?,?,?,?)",
            (session["uid"], f["category"], f["title"].strip(), f["description"].strip(),
             f.get("address", "").strip(), lat, lng, att))
        notify(session["uid"], "Your complaint #%d '%s' has been registered." % (cid, f["title"].strip()))
        flash("Complaint #%d registered." % cid, "success")
        return redirect(url_for("complaint_view", cid=cid))
    return render_template("complaint_form.html", categories=CATEGORIES)


@app.route("/complaints")
@login_required("user")
def my_complaints():
    status = request.args.get("status", "")
    sql = "SELECT * FROM complaints WHERE user_id=?"
    args = [session["uid"]]
    if status in STATUSES:
        sql += " AND status=?"
        args.append(status)
    rows = query(sql + " ORDER BY id DESC", args)
    return render_template("complaint_list.html", rows=rows, statuses=STATUSES, status=status, title="My Complaints")


@app.route("/complaint/<int:cid>")
@login_required()
def complaint_view(cid):
    c = query("""SELECT c.*, u.name uname, u.email uemail, u.phone uphone, o.name oname, o.code ocode
                 FROM complaints c JOIN users u ON u.id=c.user_id LEFT JOIN users o ON o.id=c.officer_id
                 WHERE c.id=?""", (cid,), one=True)
    if not c:
        abort(404)
    if not can_view(c):
        abort(403)
    ups = query("SELECT up.*, u.name, u.role FROM updates up JOIN users u ON u.id=up.author_id WHERE complaint_id=? ORDER BY up.id", (cid,))
    fb = query("SELECT * FROM feedback WHERE complaint_id=?", (cid,), one=True)
    officers = query("SELECT id,name,code FROM users WHERE role='officer'") if session["role"] == "admin" else []
    return render_template("complaint_view.html", c=c, ups=ups, fb=fb, statuses=STATUSES, officers=officers)


@app.route("/complaint/<int:cid>/info", methods=["POST"])
@login_required("user")
def add_info(cid):
    c = query("SELECT * FROM complaints WHERE id=? AND user_id=?", (cid, session["uid"]), one=True)
    if not c:
        abort(404)
    msg = request.form.get("message", "").strip()
    f = save_upload(request.files.get("file"), DOC_EXT)
    if msg or f:
        execute("INSERT INTO updates(complaint_id,author_id,message,file) VALUES(?,?,?,?)", (cid, session["uid"], msg, f))
        if c["officer_id"]:
            notify(c["officer_id"], "User added new information to complaint #%d." % cid)
        flash("Additional information added.", "success")
    return redirect(url_for("complaint_view", cid=cid))


@app.route("/complaint/<int:cid>/feedback", methods=["POST"])
@login_required("user")
def give_feedback(cid):
    if not feature_on("feedback"):
        abort(404)
    c = query("SELECT * FROM complaints WHERE id=? AND user_id=?", (cid, session["uid"]), one=True)
    if not c or c["status"] not in ("Resolved", "Rejected"):
        flash("Feedback can be given once a complaint is closed.", "error")
    elif query("SELECT 1 FROM feedback WHERE complaint_id=?", (cid,), one=True):
        flash("Feedback already submitted.", "error")
    else:
        rating = max(1, min(5, int(request.form.get("rating", 5))))
        execute("INSERT INTO feedback(complaint_id,user_id,rating,comment) VALUES(?,?,?,?)",
                (cid, session["uid"], rating, request.form.get("comment", "").strip()))
        flash("Thank you for your feedback.", "success")
    return redirect(url_for("complaint_view", cid=cid))


@app.route("/contact")
@login_required("user")
def contact():
    if not feature_on("contact"):
        abort(404)
    admins = query("SELECT name,email,phone FROM users WHERE role='admin'")
    return render_template("contact.html", admins=admins)


@app.route("/notifications")
@login_required("user", "officer")
def notifications():
    rows = query("SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 50", (session["uid"],))
    return render_template("notifications.html", rows=rows)


@app.route("/search")
def search():
    if not feature_on("search"):
        abort(404)
    q = request.args.get("q", "").strip()
    if q:
        like = "%" + q + "%"
        rows = query("SELECT * FROM faq WHERE issue LIKE ? OR solution LIKE ? OR category LIKE ?", (like, like, like))
    else:
        rows = query("SELECT * FROM faq ORDER BY category")
    return render_template("search.html", rows=rows, q=q)


# ------------------------------------------------------------------ officer
@app.route("/officer")
@login_required("officer")
def officer_home():
    status = request.args.get("status", "")
    scope = request.args.get("scope", "mine")
    sql = "SELECT c.*, u.name uname FROM complaints c JOIN users u ON u.id=c.user_id WHERE 1=1"
    args = []
    if scope == "mine":
        sql += " AND (c.officer_id=? OR c.officer_id IS NULL)"
        args.append(session["uid"])
    if status in STATUSES:
        sql += " AND c.status=?"
        args.append(status)
    rows = query(sql + " ORDER BY c.id DESC", args)
    return render_template("complaint_list.html", rows=rows, statuses=STATUSES, status=status,
                           title="Complaints", officer=True, scope=scope)


@app.route("/complaint/<int:cid>/update", methods=["POST"])
@login_required("officer", "admin")
def update_status(cid):
    c = query("SELECT * FROM complaints WHERE id=?", (cid,), one=True)
    if not c:
        abort(404)
    status = request.form["status"]
    if status not in STATUSES:
        abort(400)
    if session["role"] == "officer" and c["officer_id"] not in (None, session["uid"]):
        flash("This complaint is handled by another officer.", "error")
        return redirect(url_for("complaint_view", cid=cid))
    note = request.form.get("note", "").strip()
    proof = save_upload(request.files.get("proof"), IMG_EXT | {"pdf"})
    oid = c["officer_id"] or (session["uid"] if session["role"] == "officer" else None)
    execute("UPDATE complaints SET status=?, officer_id=?, proof=COALESCE(?,proof), proof_note=COALESCE(NULLIF(?,''),proof_note), updated=CURRENT_TIMESTAMP WHERE id=?",
            (status, oid, proof, note, cid))
    if note or proof:
        execute("INSERT INTO updates(complaint_id,author_id,message,file) VALUES(?,?,?,?)", (cid, session["uid"], note, proof))
    notify(c["user_id"], "Complaint #%d status is now '%s'. %s" % (cid, status, note))
    flash("Status updated and the user was notified.", "success")
    return redirect(url_for("complaint_view", cid=cid))


# -------------------------------------------------------------------- admin
@app.route("/admin")
@login_required("admin")
def admin_home():
    stats = {s: query("SELECT COUNT(*) c FROM complaints WHERE status=?", (s,), one=True)["c"] for s in STATUSES}
    by_cat = query("SELECT category, COUNT(*) c FROM complaints GROUP BY category ORDER BY c DESC")
    avg = query("SELECT ROUND(AVG(rating),2) a, COUNT(*) n FROM feedback", one=True)
    rows = query("SELECT c.*, u.name uname, o.name oname FROM complaints c JOIN users u ON u.id=c.user_id LEFT JOIN users o ON o.id=c.officer_id ORDER BY c.id DESC LIMIT 100")
    officers = query("SELECT id,name,code FROM users WHERE role='officer'")
    return render_template("admin_home.html", stats=stats, by_cat=by_cat, avg=avg, rows=rows, officers=officers)


@app.route("/admin/assign/<int:cid>", methods=["POST"])
@login_required("admin")
def admin_assign(cid):
    oid = int(request.form["officer_id"])
    execute("UPDATE complaints SET officer_id=?, status=CASE WHEN status='Pending' THEN 'Assigned' ELSE status END, updated=CURRENT_TIMESTAMP WHERE id=?", (oid, cid))
    notify(oid, "Complaint #%d has been assigned to you." % cid)
    flash("Complaint assigned.", "success")
    return redirect(request.referrer or url_for("admin_home"))


@app.route("/admin/users")
@login_required("admin")
def admin_users():
    role = request.args.get("role", "")
    users = query("SELECT * FROM users WHERE (?='' OR role=?) ORDER BY role, id", (role, role))
    return render_template("admin_users.html", users=users, role=role)


@app.route("/admin/users/create", methods=["POST"])
@login_required("admin")
def admin_create_user():
    role = request.form.get("role", "officer")
    if role not in ("officer", "user", "admin"):
        abort(400)
    email = request.form["email"].strip().lower()
    if query("SELECT 1 FROM users WHERE email=?", (email,), one=True):
        flash("E-mail already exists.", "error")
        return redirect(url_for("admin_users"))
    alphabet = string.ascii_letters + string.digits
    pw = "".join(secrets.choice(alphabet) for _ in range(10))
    code = next_officer_code() if role == "officer" else None
    execute("INSERT INTO users(code,name,email,phone,password,role) VALUES(?,?,?,?,?,?)",
            (code, request.form["name"].strip(), email, request.form.get("phone", ""), generate_password_hash(pw), role))
    flash("Account created. Login: %s  |  Password: %s  (share securely - shown only once)" % (code or email, pw), "success")
    return redirect(url_for("admin_users"))


@app.route("/admin/users/<int:uid>")
@login_required("admin")
def admin_user(uid):
    u = query("SELECT * FROM users WHERE id=?", (uid,), one=True)
    if not u:
        abort(404)
    rows = query("SELECT c.*, u.name uname FROM complaints c JOIN users u ON u.id=c.user_id WHERE c.user_id=? OR c.officer_id=? ORDER BY c.id DESC", (uid, uid))
    return render_template("admin_user.html", u=u, rows=rows)


@app.route("/admin/users/<int:uid>/password", methods=["POST"])
@login_required("admin")
def admin_password(uid):
    pw = request.form["password"]
    if len(pw) < 6:
        flash("Password must be at least 6 characters.", "error")
    else:
        execute("UPDATE users SET password=? WHERE id=?", (generate_password_hash(pw), uid))
        flash("Password changed.", "success")
    return redirect(url_for("admin_user", uid=uid))


@app.route("/admin/users/<int:uid>/delete", methods=["POST"])
@login_required("admin")
def admin_delete(uid):
    if uid == session["uid"]:
        flash("You cannot delete your own account.", "error")
    else:
        execute("DELETE FROM users WHERE id=?", (uid,))
        flash("Account deleted.", "success")
    return redirect(url_for("admin_users"))


@app.route("/admin/features", methods=["GET", "POST"])
@login_required("admin")
def admin_features():
    if request.method == "POST":
        on = set(request.form.getlist("visible"))
        for name, _ in FEATURES:
            execute("UPDATE features SET visible=? WHERE name=?", (1 if name in on else 0, name))
        flash("Feature visibility saved.", "success")
        return redirect(url_for("admin_features"))
    feats = query("SELECT * FROM features")
    faqs = query("SELECT * FROM faq ORDER BY category")
    return render_template("admin_features.html", feats=feats, faqs=faqs)


@app.route("/admin/faq", methods=["POST"])
@login_required("admin")
def admin_faq():
    execute("INSERT INTO faq(category,issue,solution) VALUES(?,?,?)",
            (request.form["category"], request.form["issue"], request.form["solution"]))
    flash("Information added.", "success")
    return redirect(url_for("admin_features"))


if __name__ == "__main__":
    app.run(debug=os.environ.get("DEBUG") == "1", port=int(os.environ.get("PORT", 5000)))
