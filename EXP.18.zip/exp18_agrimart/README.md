# Experiment 18 - AgriMart (Agricultural Marketplace)

Flask + SQLite web application for **Farmers** (sellers) and **Public/Customers** (buyers).

## Run
```bash
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py                                         # http://127.0.0.1:5000
```
`app.db` is created automatically from `schema.sql` with demo data (6 products).

## Demo accounts
| Role     | E-mail                 | Password    |
|----------|------------------------|-------------|
| Farmer   | farmer@agrimart.test   | farmer123   |
| Customer | customer@agrimart.test | customer123 (wallet starts at ₹5000) |

Registration and every login require an **OTP** (shown on screen in demo mode and printed in the console).

## Features
**Farmer:** register, OTP verification, login/logout, add product, update/delete product, **upload (multiple) images**,
manage orders, update order status (Placed / Confirmed / Completed / Cancelled), update shipping status
(Not shipped / Packed / Shipped / Out for delivery / Delivered), **My Sales** (by product and month), dashboard with low-stock alerts.

**Customer (public):** register, OTP verification, login, my account (profile), **manage wallet balance** (top-up, history),
view product details, **search & filter** (keyword, category, price range, sort), add to cart, edit/delete cart,
add/edit/delete shipping addresses, order products (paid from wallet), my order status, **view shipping status** (progress tracker),
cancel before shipping (automatic refund), personalised recommendations from purchase history.

## Business rules
- Stock is reduced at checkout (transaction) and restored on cancellation.
- Customer pays from wallet at checkout; the farmer's wallet is credited when the item is marked Delivered/Completed.
- Order lines keep a copy of name/price, so history survives product edits/deletes.
- The payment gateway for wallet top-ups is simulated.

## Structure
`app.py` - `common.py` - `schema.sql` (users, products, product_images, cart, addresses, orders, order_items, wallet_tx) - `templates/` - `static/`
