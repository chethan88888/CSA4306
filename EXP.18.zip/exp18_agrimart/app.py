"""AgriMart - online agricultural marketplace for farmers and customers (Flask + SQLite)."""
import os

from flask import Flask, render_template, request, redirect, url_for, flash, session, abort
from werkzeug.security import generate_password_hash, check_password_hash

from common import (setup, query, execute, get_db, login_required, start_session, send_otp,
                    check_otp, save_upload, IMG_EXT)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-change-me")

CATEGORIES = ["Seeds", "Fertilizers", "Pesticides", "Farming Equipment", "Tools"]
ORDER_STATUS = ["Placed", "Confirmed", "Completed", "Cancelled"]
SHIPPING = ["Not shipped", "Packed", "Shipped", "Out for delivery", "Delivered"]


def seed(db):
    if db.execute("SELECT 1 FROM users").fetchone():
        return
    for role, name, email, pw, wallet in [("farmer", "Green Acres Farm", "farmer@agrimart.test", "farmer123", 0),
                                          ("customer", "Demo Customer", "customer@agrimart.test", "customer123", 5000)]:
        db.execute("INSERT INTO users(role,name,email,phone,password,verified,wallet) VALUES(?,?,?,?,?,1,?)",
                   (role, name, email, "9876543210", generate_password_hash(pw), wallet))
    items = [("Hybrid Tomato Seeds (50 g)", "Seeds", 220, 100, "High-yield, disease-resistant hybrid tomato seeds."),
             ("Paddy Seeds IR-64 (5 kg)", "Seeds", 450, 60, "Certified paddy seed with 95% germination."),
             ("NPK 19-19-19 (1 kg)", "Fertilizers", 180, 200, "Water-soluble balanced fertilizer for all crops."),
             ("Neem Oil Pesticide (1 L)", "Pesticides", 340, 80, "Organic neem-based pest control."),
             ("Hand Sprayer 16 L", "Farming Equipment", 1650, 25, "Knapsack sprayer with adjustable nozzle."),
             ("Garden Trowel Set", "Tools", 299, 70, "Stainless steel, 3-piece set.")]
    for n, c, p, s, d in items:
        db.execute("INSERT INTO products(farmer_id,name,category,price,stock,description) VALUES(1,?,?,?,?,?)", (n, c, p, s, d))
    db.execute("INSERT INTO addresses(user_id,label,line1,city,state,pincode,phone) VALUES(2,'Home','12 Market Road','Erode','Tamil Nadu','638001','9876543210')")


setup(app, seed)


@app.template_filter("inr")
def inr(v):
    return "₹{:,.2f}".format(v or 0)


@app.context_processor
def inject():
    role = session.get("role")
    nav = [("index", "Shop")]
    if role == "customer":
        n = query("SELECT COALESCE(SUM(qty),0) n FROM cart WHERE user_id=?", (session["uid"],), one=True)["n"]
        nav += [("cart", "Cart (%d)" % n), ("orders", "My Orders"), ("wallet", "Wallet"), ("account", "My Account")]
    elif role == "farmer":
        nav += [("farmer_home", "Dashboard"), ("farmer_products", "My Products"), ("farmer_orders", "Manage Orders"), ("farmer_sales", "My Sales")]
    nav.append(("logout", "Logout (%s)" % session["name"]) if role else ("login", "Login"))
    if not role:
        nav.append(("register", "Register"))
    return dict(brand="AgriMart", accent="#15803d", nav=nav, categories=CATEGORIES)


def cover(pid):
    r = query("SELECT filename FROM product_images WHERE product_id=? ORDER BY id LIMIT 1", (pid,), one=True)
    return r["filename"] if r else None


app.jinja_env.globals["cover"] = cover


# ------------------------------------------------------------------- auth
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        f = request.form
        email = f["email"].strip().lower()
        role = f.get("role") if f.get("role") in ("farmer", "customer") else "customer"
        if len(f["password"]) < 6:
            flash("Password must be at least 6 characters.", "error")
        else:
            old = query("SELECT * FROM users WHERE email=?", (email,), one=True)
            if old and old["verified"]:
                flash("E-mail already registered. Please log in.", "error")
                return render_template("register.html")
            if old:   # unverified leftover - overwrite
                execute("DELETE FROM users WHERE id=?", (old["id"],))
            uid = execute("INSERT INTO users(role,name,email,phone,password) VALUES(?,?,?,?,?)",
                          (role, f["name"].strip(), email, f["phone"].strip(), generate_password_hash(f["password"])))
            session.clear()
            session["pending"] = {"uid": uid, "purpose": "register"}
            send_otp("register", f["phone"])
            return redirect(url_for("verify"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = query("SELECT * FROM users WHERE email=?", (request.form["email"].strip().lower(),), one=True)
        if u and check_password_hash(u["password"], request.form["password"]):
            purpose = "login" if u["verified"] else "register"
            session.clear()
            session["pending"] = {"uid": u["id"], "purpose": purpose}
            send_otp(purpose, u["phone"])
            return redirect(url_for("verify"))
        flash("Invalid e-mail or password.", "error")
    return render_template("login.html")


@app.route("/verify", methods=["GET", "POST"])
def verify():
    p = session.get("pending")
    if not p:
        return redirect(url_for("login"))
    u = query("SELECT * FROM users WHERE id=?", (p["uid"],), one=True)
    if request.method == "POST":
        if request.form.get("resend"):
            send_otp(p["purpose"], u["phone"])
        elif check_otp(request.form.get("otp", ""), p["purpose"]):
            execute("UPDATE users SET verified=1 WHERE id=?", (u["id"],))
            start_session(u)
            flash("OTP verified. Welcome to AgriMart!", "success")
            return redirect(url_for("farmer_home" if u["role"] == "farmer" else "index"))
        else:
            flash("Wrong or expired OTP.", "error")
    return render_template("verify.html", phone=u["phone"][-4:], purpose=p["purpose"])


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))


# ------------------------------------------------------------------- shop
@app.route("/")
def index():
    q = request.args.get("q", "").strip()
    cat = request.args.get("category", "")
    lo = request.args.get("min", type=float)
    hi = request.args.get("max", type=float)
    sort = request.args.get("sort", "new")
    sql = "SELECT p.*, u.name farmer FROM products p JOIN users u ON u.id=p.farmer_id WHERE p.active=1"
    args = []
    if q:
        sql += " AND (p.name LIKE ? OR p.description LIKE ?)"
        args += ["%" + q + "%"] * 2
    if cat in CATEGORIES:
        sql += " AND p.category=?"
        args.append(cat)
    if lo is not None:
        sql += " AND p.price>=?"
        args.append(lo)
    if hi is not None:
        sql += " AND p.price<=?"
        args.append(hi)
    sql += {"low": " ORDER BY p.price", "high": " ORDER BY p.price DESC", "name": " ORDER BY p.name"}.get(sort, " ORDER BY p.id DESC")
    products = query(sql, args)
    recs = []
    if session.get("role") == "customer" and not (q or cat or lo or hi):
        recs = query("""SELECT DISTINCT p.* FROM products p WHERE p.active=1 AND p.stock>0
                        AND p.category IN (SELECT p2.category FROM order_items oi JOIN products p2 ON p2.id=oi.product_id
                                           JOIN orders o ON o.id=oi.order_id WHERE o.customer_id=?)
                        AND p.id NOT IN (SELECT product_id FROM order_items oi JOIN orders o ON o.id=oi.order_id
                                         WHERE o.customer_id=? AND product_id IS NOT NULL) LIMIT 4""", (session["uid"], session["uid"]))
    return render_template("index.html", products=products, recs=recs, q=q, cat=cat, lo=lo, hi=hi, sort=sort)


@app.route("/product/<int:pid>")
def product(pid):
    p = query("SELECT p.*, u.name farmer FROM products p JOIN users u ON u.id=p.farmer_id WHERE p.id=? AND p.active=1", (pid,), one=True)
    if not p:
        abort(404)
    imgs = query("SELECT filename FROM product_images WHERE product_id=? ORDER BY id", (pid,))
    return render_template("product.html", p=p, imgs=imgs)


# ----------------------------------------------------------------- customer
@app.route("/account", methods=["GET", "POST"])
@login_required("customer")
def account():
    if request.method == "POST":
        execute("UPDATE users SET name=?, phone=? WHERE id=?", (request.form["name"].strip(), request.form["phone"].strip(), session["uid"]))
        session["name"] = request.form["name"].strip()
        flash("Profile updated.", "success")
        return redirect(url_for("account"))
    me = query("SELECT * FROM users WHERE id=?", (session["uid"],), one=True)
    return render_template("account.html", me=me, addrs=query("SELECT * FROM addresses WHERE user_id=?", (session["uid"],)))


@app.route("/addresses", methods=["POST"])
@login_required("customer")
def address_save():
    f = request.form
    aid = f.get("id", type=int)
    vals = (f["label"].strip(), f["line1"].strip(), f["city"].strip(), f["state"].strip(), f["pincode"].strip(), f["phone"].strip())
    if aid:
        execute("UPDATE addresses SET label=?,line1=?,city=?,state=?,pincode=?,phone=? WHERE id=? AND user_id=?", vals + (aid, session["uid"]))
    else:
        execute("INSERT INTO addresses(label,line1,city,state,pincode,phone,user_id) VALUES(?,?,?,?,?,?,?)", vals + (session["uid"],))
    flash("Address saved.", "success")
    nxt = request.form.get("next", "")
    return redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else url_for("account"))


@app.route("/addresses/<int:aid>/delete", methods=["POST"])
@login_required("customer")
def address_delete(aid):
    execute("DELETE FROM addresses WHERE id=? AND user_id=?", (aid, session["uid"]))
    flash("Address removed.", "success")
    return redirect(request.referrer or url_for("account"))


@app.route("/wallet", methods=["GET", "POST"])
@login_required("customer")
def wallet():
    if request.method == "POST":
        amt = request.form.get("amount", type=float) or 0
        if not 1 <= amt <= 100000:
            flash("Enter an amount between 1 and 100000.", "error")
        else:
            db = get_db()
            db.execute("UPDATE users SET wallet=wallet+? WHERE id=?", (amt, session["uid"]))
            db.execute("INSERT INTO wallet_tx(user_id,amount,note) VALUES(?,?,?)", (session["uid"], amt, "Wallet top-up (%s)" % request.form.get("method", "UPI")))
            db.commit()
            flash("Added %s to your wallet (payment gateway simulated)." % inr(amt), "success")
        return redirect(url_for("wallet"))
    me = query("SELECT wallet FROM users WHERE id=?", (session["uid"],), one=True)
    return render_template("wallet.html", bal=me["wallet"], tx=query("SELECT * FROM wallet_tx WHERE user_id=? ORDER BY id DESC LIMIT 30", (session["uid"],)))


@app.route("/cart", methods=["GET", "POST"])
@login_required("customer")
def cart():
    if request.method == "POST":
        for k, v in request.form.items():
            if k.startswith("qty_"):
                pid, qty = int(k[4:]), int(v or 0)
                if qty <= 0:
                    execute("DELETE FROM cart WHERE user_id=? AND product_id=?", (session["uid"], pid))
                else:
                    stock = query("SELECT stock FROM products WHERE id=?", (pid,), one=True)
                    execute("UPDATE cart SET qty=? WHERE user_id=? AND product_id=?", (min(qty, stock["stock"] if stock else qty), session["uid"], pid))
        flash("Cart updated.", "success")
        return redirect(url_for("cart"))
    items = query("""SELECT c.qty, p.* FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=?""", (session["uid"],))
    return render_template("cart.html", items=items, total=sum(i["qty"] * i["price"] for i in items))


@app.route("/cart/add/<int:pid>", methods=["POST"])
@login_required("customer")
def cart_add(pid):
    p = query("SELECT * FROM products WHERE id=? AND active=1", (pid,), one=True)
    if not p or p["stock"] <= 0:
        flash("Product unavailable.", "error")
        return redirect(url_for("index"))
    qty = max(1, request.form.get("qty", 1, type=int))
    cur = query("SELECT qty FROM cart WHERE user_id=? AND product_id=?", (session["uid"], pid), one=True)
    new = min(p["stock"], qty + (cur["qty"] if cur else 0))
    execute("INSERT INTO cart(user_id,product_id,qty) VALUES(?,?,?) ON CONFLICT(user_id,product_id) DO UPDATE SET qty=excluded.qty", (session["uid"], pid, new))
    flash("Added to cart.", "success")
    return redirect(request.referrer or url_for("cart"))


@app.route("/cart/remove/<int:pid>", methods=["POST"])
@login_required("customer")
def cart_remove(pid):
    execute("DELETE FROM cart WHERE user_id=? AND product_id=?", (session["uid"], pid))
    return redirect(url_for("cart"))


@app.route("/checkout", methods=["GET", "POST"])
@login_required("customer")
def checkout():
    items = query("SELECT c.qty, p.* FROM cart c JOIN products p ON p.id=c.product_id WHERE c.user_id=?", (session["uid"],))
    if not items:
        flash("Your cart is empty.", "error")
        return redirect(url_for("cart"))
    total = round(sum(i["qty"] * i["price"] for i in items), 2)
    addrs = query("SELECT * FROM addresses WHERE user_id=?", (session["uid"],))
    me = query("SELECT * FROM users WHERE id=?", (session["uid"],), one=True)
    if request.method == "POST":
        a = query("SELECT * FROM addresses WHERE id=? AND user_id=?", (request.form.get("address_id", type=int), session["uid"]), one=True)
        if not a:
            flash("Choose a shipping address.", "error")
        elif me["wallet"] < total:
            flash("Insufficient wallet balance. Please add money first.", "error")
            return redirect(url_for("wallet"))
        elif any(i["stock"] < i["qty"] for i in items):
            flash("Some items are out of stock. Please update your cart.", "error")
            return redirect(url_for("cart"))
        else:
            db = get_db()
            try:
                ship = "%s, %s, %s - %s | Ph: %s" % (a["line1"], a["city"], a["state"], a["pincode"], a["phone"])
                oid = db.execute("INSERT INTO orders(customer_id,ship_to,total) VALUES(?,?,?)", (session["uid"], ship, total)).lastrowid
                for i in items:
                    db.execute("INSERT INTO order_items(order_id,product_id,farmer_id,name,price,qty) VALUES(?,?,?,?,?,?)",
                               (oid, i["id"], i["farmer_id"], i["name"], i["price"], i["qty"]))
                    db.execute("UPDATE products SET stock=stock-? WHERE id=?", (i["qty"], i["id"]))
                db.execute("UPDATE users SET wallet=wallet-? WHERE id=?", (total, session["uid"]))
                db.execute("INSERT INTO wallet_tx(user_id,amount,note) VALUES(?,?,?)", (session["uid"], -total, "Order #%d" % oid))
                db.execute("DELETE FROM cart WHERE user_id=?", (session["uid"],))
                db.commit()
            except Exception:
                db.rollback()
                flash("Could not place the order. Please try again.", "error")
                return redirect(url_for("cart"))
            flash("Order #%d placed and paid from wallet." % oid, "success")
            return redirect(url_for("order_detail", oid=oid))
    return render_template("checkout.html", items=items, total=total, addrs=addrs, bal=me["wallet"])


@app.route("/orders")
@login_required("customer")
def orders():
    rows = query("SELECT * FROM orders WHERE customer_id=? ORDER BY id DESC", (session["uid"],))
    return render_template("orders.html", rows=rows)


@app.route("/orders/<int:oid>")
@login_required("customer")
def order_detail(oid):
    o = query("SELECT * FROM orders WHERE id=? AND customer_id=?", (oid, session["uid"]), one=True)
    if not o:
        abort(404)
    items = query("SELECT oi.*, u.name farmer FROM order_items oi JOIN users u ON u.id=oi.farmer_id WHERE order_id=?", (oid,))
    return render_template("order_detail.html", o=o, items=items, steps=SHIPPING)


@app.route("/orders/item/<int:iid>/cancel", methods=["POST"])
@login_required("customer")
def cancel_item(iid):
    it = query("SELECT oi.* FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE oi.id=? AND o.customer_id=?", (iid, session["uid"]), one=True)
    if not it or it["status"] not in ("Placed", "Confirmed") or it["shipping"] not in ("Not shipped", "Packed"):
        flash("This item can no longer be cancelled.", "error")
    else:
        refund_item(it)
        flash("Item cancelled and refunded to your wallet.", "success")
    return redirect(url_for("order_detail", oid=it["order_id"] if it else 0))


def refund_item(it):
    db = get_db()
    db.execute("UPDATE order_items SET status='Cancelled', updated=CURRENT_TIMESTAMP WHERE id=?", (it["id"],))
    if it["product_id"]:
        db.execute("UPDATE products SET stock=stock+? WHERE id=?", (it["qty"], it["product_id"]))
    cust = db.execute("SELECT customer_id FROM orders WHERE id=?", (it["order_id"],)).fetchone()["customer_id"]
    amt = it["price"] * it["qty"]
    db.execute("UPDATE users SET wallet=wallet+? WHERE id=?", (amt, cust))
    db.execute("INSERT INTO wallet_tx(user_id,amount,note) VALUES(?,?,?)", (cust, amt, "Refund order #%d (%s)" % (it["order_id"], it["name"])))
    db.commit()


# ------------------------------------------------------------------ farmer
@app.route("/farmer")
@login_required("farmer")
def farmer_home():
    uid = session["uid"]
    s = query("""SELECT COUNT(*) items, COALESCE(SUM(CASE WHEN status='Completed' THEN price*qty END),0) revenue,
                 COALESCE(SUM(CASE WHEN status IN ('Placed','Confirmed') THEN 1 END),0) pending FROM order_items WHERE farmer_id=?""", (uid,), one=True)
    prods = query("SELECT COUNT(*) c FROM products WHERE farmer_id=?", (uid,), one=True)["c"]
    low = query("SELECT * FROM products WHERE farmer_id=? AND stock<=5 AND active=1", (uid,))
    bal = query("SELECT wallet FROM users WHERE id=?", (uid,), one=True)["wallet"]
    return render_template("farmer_home.html", s=s, prods=prods, low=low, bal=bal)


@app.route("/farmer/products")
@login_required("farmer")
def farmer_products():
    rows = query("SELECT * FROM products WHERE farmer_id=? ORDER BY id DESC", (session["uid"],))
    return render_template("farmer_products.html", rows=rows)


@app.route("/farmer/products/add", methods=["GET", "POST"])
@app.route("/farmer/products/<int:pid>/edit", methods=["GET", "POST"])
@login_required("farmer")
def farmer_product_form(pid=None):
    p = None
    if pid:
        p = query("SELECT * FROM products WHERE id=? AND farmer_id=?", (pid, session["uid"]), one=True)
        if not p:
            abort(404)
    if request.method == "POST":
        f = request.form
        vals = (f["name"].strip(), f["category"], max(0, f.get("price", type=float) or 0), max(0, f.get("stock", type=int) or 0),
                f["description"].strip(), 1 if f.get("active") else 0)
        if f["category"] not in CATEGORIES:
            abort(400)
        if p:
            execute("UPDATE products SET name=?,category=?,price=?,stock=?,description=?,active=? WHERE id=?", vals + (pid,))
        else:
            pid = execute("INSERT INTO products(name,category,price,stock,description,active,farmer_id) VALUES(?,?,?,?,?,?,?)", vals + (session["uid"],))
        for file in request.files.getlist("images"):
            name = save_upload(file, IMG_EXT)
            if name:
                execute("INSERT INTO product_images(product_id,filename) VALUES(?,?)", (pid, name))
        flash("Product saved.", "success")
        return redirect(url_for("farmer_product_form", pid=pid))
    imgs = query("SELECT * FROM product_images WHERE product_id=?", (pid,)) if pid else []
    return render_template("farmer_product_form.html", p=p, imgs=imgs)


@app.route("/farmer/images/<int:iid>/delete", methods=["POST"])
@login_required("farmer")
def farmer_image_delete(iid):
    img = query("SELECT i.*, p.farmer_id FROM product_images i JOIN products p ON p.id=i.product_id WHERE i.id=?", (iid,), one=True)
    if not img or img["farmer_id"] != session["uid"]:
        abort(404)
    execute("DELETE FROM product_images WHERE id=?", (iid,))
    try:
        os.remove(os.path.join(app.config["UPLOAD_FOLDER"], img["filename"]))
    except OSError:
        pass
    return redirect(url_for("farmer_product_form", pid=img["product_id"]))


@app.route("/farmer/products/<int:pid>/delete", methods=["POST"])
@login_required("farmer")
def farmer_product_delete(pid):
    p = query("SELECT * FROM products WHERE id=? AND farmer_id=?", (pid, session["uid"]), one=True)
    if not p:
        abort(404)
    execute("DELETE FROM cart WHERE product_id=?", (pid,))
    execute("DELETE FROM products WHERE id=?", (pid,))   # order history keeps its own copy of name/price
    flash("Product deleted.", "success")
    return redirect(url_for("farmer_products"))


@app.route("/farmer/orders")
@login_required("farmer")
def farmer_orders():
    flt = request.args.get("status", "")
    sql = """SELECT oi.*, o.ship_to, o.created, u.name customer FROM order_items oi JOIN orders o ON o.id=oi.order_id
             JOIN users u ON u.id=o.customer_id WHERE oi.farmer_id=?"""
    args = [session["uid"]]
    if flt in ORDER_STATUS:
        sql += " AND oi.status=?"
        args.append(flt)
    rows = query(sql + " ORDER BY oi.id DESC", args)
    return render_template("farmer_orders.html", rows=rows, flt=flt, statuses=ORDER_STATUS, steps=SHIPPING)


@app.route("/farmer/orders/<int:iid>", methods=["POST"])
@login_required("farmer")
def farmer_order_update(iid):
    it = query("SELECT * FROM order_items WHERE id=? AND farmer_id=?", (iid, session["uid"]), one=True)
    if not it:
        abort(404)
    status, shipping = request.form.get("status", it["status"]), request.form.get("shipping", it["shipping"])
    if status not in ORDER_STATUS or shipping not in SHIPPING:
        abort(400)
    if it["status"] in ("Cancelled", "Completed"):
        flash("This item is closed and cannot be changed.", "error")
    elif status == "Cancelled":
        refund_item(it)
        flash("Item cancelled; customer refunded.", "success")
    else:
        if shipping == "Delivered":
            status = "Completed"
        db = get_db()
        db.execute("UPDATE order_items SET status=?, shipping=?, updated=CURRENT_TIMESTAMP WHERE id=?", (status, shipping, iid))
        if status == "Completed":      # money reaches the farmer on delivery
            amt = it["price"] * it["qty"]
            db.execute("UPDATE users SET wallet=wallet+? WHERE id=?", (amt, session["uid"]))
            db.execute("INSERT INTO wallet_tx(user_id,amount,note) VALUES(?,?,?)", (session["uid"], amt, "Sale: order #%d (%s)" % (it["order_id"], it["name"])))
        db.commit()
        flash("Order updated.", "success")
    return redirect(url_for("farmer_orders"))


@app.route("/farmer/sales")
@login_required("farmer")
def farmer_sales():
    uid = session["uid"]
    by_prod = query("""SELECT name, SUM(qty) units, SUM(price*qty) revenue FROM order_items WHERE farmer_id=? AND status='Completed'
                       GROUP BY name ORDER BY revenue DESC""", (uid,))
    monthly = query("""SELECT substr(updated,1,7) month, SUM(price*qty) revenue FROM order_items WHERE farmer_id=? AND status='Completed'
                       GROUP BY month ORDER BY month DESC""", (uid,))
    bal = query("SELECT wallet FROM users WHERE id=?", (uid,), one=True)["wallet"]
    return render_template("farmer_sales.html", by_prod=by_prod, monthly=monthly, bal=bal)


if __name__ == "__main__":
    app.run(debug=os.environ.get("DEBUG") == "1", port=int(os.environ.get("PORT", 5000)))
