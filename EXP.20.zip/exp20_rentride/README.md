# Experiment 20 - RentRide (Vehicle Rental Platform)

Flask + SQLite web application with **Admin** and **User** roles.

## Run
```bash
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py                                         # http://127.0.0.1:5000
```
`app.db` is created automatically from `schema.sql` with demo data (6 vehicles).

## Demo accounts
| Role  | E-mail             | Password |
|-------|--------------------|----------|
| Admin | admin@rentride.test | admin123 |
| User  | user@rentride.test  | user123  |

## Features (mapped to the lab sheet)
**Key features:** **search module** (type, location, keyword, max price, pick-up/return dates - vehicles already booked for the
dates are hidden), **appointment (booking)** with live price estimate, **check-in form** (licence no., ID proof, notes),
**appointment management** (cancel, status tracking), **schedule a timing** (pick-up time slot in the check-in form),
**past appointment management** (upcoming vs past lists), **reviews & ratings** after a completed rental,
booking confirmations through the Notifications page.

**Admin:** login, add vehicle, manage vehicle details (type, price, seats, location, status, photo; edit/delete),
manage booking details (**approve** / reject, mark returned), dashboard, my profile.

**User:** register, login, search vehicle details, select vehicle & make booking (name, customer no., address, type,
payment method), view booking status, my profile.

## Rules
- Date ranges are inclusive; two Pending/Approved bookings can never overlap on the same vehicle.
- Payment is simulated (Card/UPI are marked paid, "Pay at pickup" stays unpaid).
- Check-in opens only after the admin approves the booking.

## Structure
`app.py` - `common.py` - `schema.sql` (users, vehicles, bookings, checkins, reviews, notifications) - `templates/` - `static/`
