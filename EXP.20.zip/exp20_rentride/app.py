"""RentRide - online vehicle rental platform (Flask + SQLite)."""
import os
from datetime import date, datetime

from flask import Flask, render_template, request, redirect, url_for, flash, session, abort
from werkzeug.security import generate_password_hash, check_password_hash

from common import (setup, query, execute, login_required, start_session, save_upload,
                    IMG_EXT, DOC_EXT)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-change-me")

TYPES = ["Car", "SUV", "Truck", "Van", "Bike"]
SLOTS = ["08:00 - 10:00", "10:00 - 12:00", "12:00 - 14:00", "14:00 - 16:00", "16:00 - 18:00", "18:00 - 20:00"]
PAY = ["Card", "UPI", "Pay at pickup"]
EMOJI = {"Car": "🚗", "SUV": "🚙", "Truck": "🛻", "Van": "🚐", "Bike": "🏍️"}


def seed(db):
    if db.execute("SELECT 1 FROM users").fetchone():
        return
    for role, name, email, pw in [("admin", "RentRide Admin", "admin@rentride.test", "admin123"), ("user", "Demo Customer", "user@rentride.test", "user123")]:
        db.execute("INSERT INTO users(role,name,email,phone,address,password) VALUES(?,?,?,?,?,?)",
                   (role, name, email, "9876543210", "12 Main Street, Erode", generate_password_hash(pw)))
    db.executemany("INSERT INTO vehicles(name,type,seats,fuel,transmission,location,price,description) VALUES(?,?,?,?,?,?,?,?)", [
        ("Maruti Swift", "Car", 5, "Petrol", "Manual", "Erode", 1500, "Compact hatchback, great mileage for city trips."),
        ("Hyundai Creta", "SUV", 5, "Diesel", "Automatic", "Coimbatore", 3200, "Comfortable SUV with sunroof and rear AC."),
        ("Toyota Innova", "Van", 7, "Diesel", "Manual", "Erode", 3800, "Spacious 7-seater for family trips."),
        ("Tata 407", "Truck", 2, "Diesel", "Manual", "Salem", 4500, "Light commercial truck, 2.5 tonne payload."),
        ("Honda Activa", "Bike", 2, "Petrol", "Automatic", "Erode", 450, "Easy scooter, two helmets included."),
        ("Mahindra Thar", "SUV", 4, "Diesel", "Manual", "Salem", 4000, "Off-road capable 4x4 for weekend adventures.")])


setup(app, seed)


def money(v):
    return "₹{:,.0f}".format(v or 0)


app.jinja_env.filters["inr"] = money
app.jinja_env.globals["EMOJI"] = EMOJI


@app.context_processor
def inject():
    role = session.get("role")
    nav = [("index", "Home"), ("vehicles", "Search Vehicles")]
    if role == "user":
        nav += [("my_bookings", "My Bookings"), ("notifications", "Notifications"), ("profile", "My Profile")]
    elif role == "admin":
        nav += [("admin_home", "Dashboard"), ("admin_vehicles", "Vehicles"), ("admin_bookings", "Bookings"), ("profile", "My Profile")]
    nav.append(("logout", "Logout (%s)" % session["name"]) if role else ("login", "Login"))
    if not role:
        nav.append(("register", "Register"))
    return dict(brand="RentRide", accent="#be123c", nav=nav, types=TYPES, today=date.today().isoformat())


def notify(uid, msg):
    execute("INSERT INTO notifications(user_id,message) VALUES(?,?)", (uid, msg))
    print("[NOTIFY user %s] %s" % (uid, msg))


def is_free(vid, start, end, ignore=None):
    sql = "SELECT 1 FROM bookings WHERE vehicle_id=? AND status IN ('Pending','Approved') AND start_date<=? AND end_date>=?"
    args = [vid, end, start]
    if ignore:
        sql += " AND id!=?"
        args.append(ignore)
    return query(sql, args, one=True) is None


def parse_dates(s, e):
    try:
        a, b = datetime.strptime(s, "%Y-%m-%d").date(), datetime.strptime(e, "%Y-%m-%d").date()
    except (ValueError, TypeError):
        return None
    return (a, b, (b - a).days + 1) if b >= a else None


# --------------------------------------------------------------------- auth
@app.route("/")
def index():
    featured = query("SELECT v.*, (SELECT ROUND(AVG(rating),1) FROM reviews WHERE vehicle_id=v.id) rating FROM vehicles v WHERE status='available' ORDER BY id LIMIT 6")
    return render_template("index.html", featured=featured)


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        f = request.form
        email = f["email"].strip().lower()
        if len(f["password"]) < 6:
            flash("Password must be at least 6 characters.", "error")
        elif query("SELECT 1 FROM users WHERE email=?", (email,), one=True):
            flash("E-mail already registered.", "error")
        else:
            execute("INSERT INTO users(name,email,phone,address,password) VALUES(?,?,?,?,?)",
                    (f["name"].strip(), email, f["phone"].strip(), f.get("address", "").strip(), generate_password_hash(f["password"])))
            flash("Registration successful. Please log in.", "success")
            return redirect(url_for("login"))
    return render_template("register.html")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = query("SELECT * FROM users WHERE email=?", (request.form["email"].strip().lower(),), one=True)
        if u and check_password_hash(u["password"], request.form["password"]):
            start_session(u)
            nxt = request.args.get("next", "")
            if nxt.startswith("/") and not nxt.startswith("//"):
                return redirect(nxt)
            return redirect(url_for("admin_home" if u["role"] == "admin" else "vehicles"))
        flash("Invalid e-mail or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))


@app.route("/profile", methods=["GET", "POST"])
@login_required()
def profile():
    if request.method == "POST":
        f = request.form
        execute("UPDATE users SET name=?, phone=?, address=? WHERE id=?", (f["name"].strip(), f["phone"].strip(), f["address"].strip(), session["uid"]))
        if f.get("password"):
            if len(f["password"]) < 6:
                flash("Password must be at least 6 characters.", "error")
                return redirect(url_for("profile"))
            execute("UPDATE users SET password=? WHERE id=?", (generate_password_hash(f["password"]), session["uid"]))
        session["name"] = f["name"].strip()
        flash("Profile updated.", "success")
        return redirect(url_for("profile"))
    return render_template("profile.html", me=query("SELECT * FROM users WHERE id=?", (session["uid"],), one=True))


# ----------------------------------------------------------- search & detail
@app.route("/vehicles")
def vehicles():
    a = request.args
    sql = """SELECT v.*, (SELECT ROUND(AVG(rating),1) FROM reviews WHERE vehicle_id=v.id) rating FROM vehicles v WHERE v.status='available'"""
    args = []
    if a.get("type") in TYPES:
        sql += " AND v.type=?"
        args.append(a["type"])
    if a.get("location", "").strip():
        sql += " AND v.location LIKE ?"
        args.append("%" + a["location"].strip() + "%")
    if a.get("q", "").strip():
        sql += " AND (v.name LIKE ? OR v.description LIKE ?)"
        args += ["%" + a["q"].strip() + "%"] * 2
    if a.get("max", type=float):
        sql += " AND v.price<=?"
        args.append(a.get("max", type=float))
    dates = parse_dates(a.get("start"), a.get("end")) if a.get("start") and a.get("end") else None
    if a.get("start") and a.get("end") and not dates:
        flash("Return date must be on or after the pick-up date.", "error")
    if dates:
        sql += """ AND NOT EXISTS (SELECT 1 FROM bookings b WHERE b.vehicle_id=v.id AND b.status IN ('Pending','Approved')
                   AND b.start_date<=? AND b.end_date>=?)"""
        args += [a["end"], a["start"]]
    sql += {"low": " ORDER BY v.price", "high": " ORDER BY v.price DESC"}.get(a.get("sort"), " ORDER BY v.id")
    return render_template("vehicles.html", rows=query(sql, args), a=a, days=dates[2] if dates else None)


@app.route("/vehicle/<int:vid>")
def vehicle(vid):
    v = query("SELECT * FROM vehicles WHERE id=?", (vid,), one=True)
    if not v:
        abort(404)
    revs = query("SELECT r.*, u.name FROM reviews r JOIN users u ON u.id=r.user_id WHERE r.vehicle_id=? ORDER BY r.id DESC", (vid,))
    avg = round(sum(r["rating"] for r in revs) / len(revs), 1) if revs else None
    booked = query("SELECT start_date, end_date FROM bookings WHERE vehicle_id=? AND status IN ('Pending','Approved') AND end_date>=? ORDER BY start_date", (vid, date.today().isoformat()))
    me = query("SELECT * FROM users WHERE id=?", (session["uid"],), one=True) if session.get("role") == "user" else None
    return render_template("vehicle.html", v=v, revs=revs, avg=avg, booked=booked, me=me, pay=PAY,
                           start=request.args.get("start", ""), end=request.args.get("end", ""))


# ----------------------------------------------------------------- bookings
@app.route("/book/<int:vid>", methods=["POST"])
@login_required("user")
def book(vid):
    v = query("SELECT * FROM vehicles WHERE id=? AND status='available'", (vid,), one=True)
    if not v:
        abort(404)
    f = request.form
    d = parse_dates(f.get("start_date"), f.get("end_date"))
    back = redirect(url_for("vehicle", vid=vid, start=f.get("start_date", ""), end=f.get("end_date", "")))
    if not d or d[0] < date.today():
        flash("Choose valid dates (pick-up cannot be in the past; return on/after pick-up).", "error")
        return back
    if f.get("pay_method") not in PAY:
        flash("Select a payment method.", "error")
        return back
    if not is_free(vid, f["start_date"], f["end_date"]):
        flash("Sorry, this vehicle is already booked for those dates.", "error")
        return back
    total = v["price"] * d[2]
    status = "Paid (simulated)" if f["pay_method"] != "Pay at pickup" else "Pay at pickup"
    bid = execute("""INSERT INTO bookings(user_id,vehicle_id,customer_name,customer_no,address,vtype,start_date,end_date,days,total,pay_method,pay_status)
                     VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
                  (session["uid"], vid, f["customer_name"].strip(), f["customer_no"].strip(), f["address"].strip(), v["type"],
                   f["start_date"], f["end_date"], d[2], total, f["pay_method"], status))
    notify(session["uid"], "Booking #%d for %s received (%s to %s, %s). Awaiting admin approval." % (bid, v["name"], f["start_date"], f["end_date"], money(total)))
    for a in query("SELECT id FROM users WHERE role='admin'"):
        notify(a["id"], "New booking #%d for %s awaits approval." % (bid, v["name"]))
    flash("Booking request submitted.", "success")
    return redirect(url_for("booking", bid=bid))


def get_booking(bid):
    b = query("""SELECT b.*, v.name vname, v.location, v.image, u.email uemail FROM bookings b JOIN vehicles v ON v.id=b.vehicle_id JOIN users u ON u.id=b.user_id WHERE b.id=?""", (bid,), one=True)
    if not b or (session["role"] != "admin" and b["user_id"] != session["uid"]):
        abort(404)
    return b


@app.route("/booking/<int:bid>")
@login_required()
def booking(bid):
    b = get_booking(bid)
    ci = query("SELECT * FROM checkins WHERE booking_id=?", (bid,), one=True)
    rv = query("SELECT * FROM reviews WHERE booking_id=?", (bid,), one=True)
    return render_template("booking.html", b=b, ci=ci, rv=rv, slots=SLOTS)


@app.route("/bookings")
@login_required("user")
def my_bookings():
    rows = query("SELECT b.*, v.name vname FROM bookings b JOIN vehicles v ON v.id=b.vehicle_id WHERE b.user_id=? ORDER BY b.start_date DESC", (session["uid"],))
    t = date.today().isoformat()
    upcoming = [r for r in rows if r["status"] in ("Pending", "Approved") and r["end_date"] >= t]
    past = [r for r in rows if r not in upcoming]
    return render_template("bookings.html", upcoming=upcoming, past=past)


@app.route("/booking/<int:bid>/checkin", methods=["POST"])
@login_required("user")
def checkin(bid):
    b = get_booking(bid)
    if b["status"] != "Approved":
        flash("Check-in opens once the booking is approved.", "error")
    else:
        f = request.form
        if f.get("pickup_time") not in SLOTS:
            flash("Choose a pick-up time slot.", "error")
        else:
            proof = save_upload(request.files.get("id_proof"), DOC_EXT)
            execute("""INSERT INTO checkins(booking_id,license_no,pickup_time,id_proof,notes) VALUES(?,?,?,?,?)
                       ON CONFLICT(booking_id) DO UPDATE SET license_no=excluded.license_no, pickup_time=excluded.pickup_time,
                       id_proof=COALESCE(excluded.id_proof, checkins.id_proof), notes=excluded.notes, submitted=CURRENT_TIMESTAMP""",
                    (bid, f["license_no"].strip(), f["pickup_time"], proof, f.get("notes", "").strip()))
            flash("Check-in form submitted and pick-up time scheduled.", "success")
    return redirect(url_for("booking", bid=bid))


@app.route("/booking/<int:bid>/cancel", methods=["POST"])
@login_required("user")
def cancel_booking(bid):
    b = get_booking(bid)
    if b["status"] in ("Pending", "Approved") and b["start_date"] >= date.today().isoformat():
        execute("UPDATE bookings SET status='Cancelled' WHERE id=?", (bid,))
        notify(session["uid"], "Booking #%d was cancelled." % bid)
        flash("Booking cancelled.", "success")
    else:
        flash("This booking can no longer be cancelled.", "error")
    return redirect(url_for("booking", bid=bid))


@app.route("/booking/<int:bid>/review", methods=["POST"])
@login_required("user")
def review(bid):
    b = get_booking(bid)
    if b["status"] != "Completed" or query("SELECT 1 FROM reviews WHERE booking_id=?", (bid,), one=True):
        flash("You can review a completed rental once.", "error")
    else:
        execute("INSERT INTO reviews(booking_id,user_id,vehicle_id,rating,comment) VALUES(?,?,?,?,?)",
                (bid, session["uid"], b["vehicle_id"], max(1, min(5, request.form.get("rating", 5, type=int))), request.form.get("comment", "").strip()))
        flash("Thanks for your review!", "success")
    return redirect(url_for("booking", bid=bid))


@app.route("/notifications")
@login_required("user")
def notifications():
    return render_template("notifications.html", rows=query("SELECT * FROM notifications WHERE user_id=? ORDER BY id DESC LIMIT 50", (session["uid"],)))


# -------------------------------------------------------------------- admin
@app.route("/admin")
@login_required("admin")
def admin_home():
    s = {"vehicles": query("SELECT COUNT(*) c FROM vehicles", one=True)["c"],
         "pending": query("SELECT COUNT(*) c FROM bookings WHERE status='Pending'", one=True)["c"],
         "active": query("SELECT COUNT(*) c FROM bookings WHERE status='Approved'", one=True)["c"],
         "revenue": query("SELECT COALESCE(SUM(total),0) t FROM bookings WHERE status IN ('Approved','Completed')", one=True)["t"]}
    pend = query("SELECT b.*, v.name vname FROM bookings b JOIN vehicles v ON v.id=b.vehicle_id WHERE b.status='Pending' ORDER BY b.id")
    return render_template("admin_home.html", s=s, pend=pend)


@app.route("/admin/vehicles")
@login_required("admin")
def admin_vehicles():
    return render_template("admin_vehicles.html", rows=query("SELECT * FROM vehicles ORDER BY id DESC"))


@app.route("/admin/vehicles/add", methods=["GET", "POST"])
@app.route("/admin/vehicles/<int:vid>/edit", methods=["GET", "POST"])
@login_required("admin")
def admin_vehicle_form(vid=None):
    v = None
    if vid:
        v = query("SELECT * FROM vehicles WHERE id=?", (vid,), one=True)
        if not v:
            abort(404)
    if request.method == "POST":
        f = request.form
        if f["type"] not in TYPES:
            abort(400)
        img = save_upload(request.files.get("image"), IMG_EXT)
        vals = (f["name"].strip(), f["type"], f.get("seats", type=int), f.get("fuel", ""), f.get("transmission", ""), f["location"].strip(),
                max(0, f.get("price", type=float) or 0), f.get("description", "").strip(), f.get("status", "available") if f.get("status") in ("available", "maintenance") else "available")
        if v:
            execute("UPDATE vehicles SET name=?,type=?,seats=?,fuel=?,transmission=?,location=?,price=?,description=?,status=?,image=COALESCE(?,image) WHERE id=?", vals + (img, vid))
        else:
            execute("INSERT INTO vehicles(name,type,seats,fuel,transmission,location,price,description,status,image) VALUES(?,?,?,?,?,?,?,?,?,?)", vals + (img,))
        flash("Vehicle saved.", "success")
        return redirect(url_for("admin_vehicles"))
    return render_template("admin_vehicle_form.html", v=v)


@app.route("/admin/vehicles/<int:vid>/delete", methods=["POST"])
@login_required("admin")
def admin_vehicle_delete(vid):
    if query("SELECT 1 FROM bookings WHERE vehicle_id=? AND status IN ('Pending','Approved')", (vid,), one=True):
        flash("Cannot delete a vehicle with active bookings - set it to maintenance instead.", "error")
    else:
        execute("DELETE FROM vehicles WHERE id=?", (vid,))
        flash("Vehicle deleted.", "success")
    return redirect(url_for("admin_vehicles"))


@app.route("/admin/bookings")
@login_required("admin")
def admin_bookings():
    st = request.args.get("status", "")
    rows = query("""SELECT b.*, v.name vname FROM bookings b JOIN vehicles v ON v.id=b.vehicle_id WHERE (?='' OR b.status=?) ORDER BY b.id DESC""", (st, st))
    return render_template("admin_bookings.html", rows=rows, st=st)


@app.route("/admin/bookings/<int:bid>/<action>", methods=["POST"])
@login_required("admin")
def admin_booking_action(bid, action):
    b = query("SELECT b.*, v.name vname FROM bookings b JOIN vehicles v ON v.id=b.vehicle_id WHERE b.id=?", (bid,), one=True)
    if not b:
        abort(404)
    allowed = {"approve": ("Pending", "Approved"), "reject": ("Pending", "Rejected"), "complete": ("Approved", "Completed")}
    if action not in allowed or b["status"] != allowed[action][0]:
        flash("That action is not available for this booking.", "error")
    else:
        if action == "approve" and not is_free(b["vehicle_id"], b["start_date"], b["end_date"], ignore=bid):
            flash("Dates clash with another booking.", "error")
        else:
            execute("UPDATE bookings SET status=? WHERE id=?", (allowed[action][1], bid))
            notify(b["user_id"], "Your booking #%d for %s is now %s." % (bid, b["vname"], allowed[action][1].upper()))
            flash("Booking %s." % allowed[action][1].lower(), "success")
    return redirect(request.referrer or url_for("admin_bookings"))


if __name__ == "__main__":
    app.run(debug=os.environ.get("DEBUG") == "1", port=int(os.environ.get("PORT", 5000)))
