CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  role TEXT NOT NULL DEFAULT 'user' CHECK(role IN ('user','admin')),
  name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, phone TEXT, address TEXT,
  password TEXT NOT NULL,
  created TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS vehicles(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  type TEXT NOT NULL,                          -- Car, SUV, Truck, Van, Bike
  seats INTEGER, fuel TEXT, transmission TEXT,
  location TEXT NOT NULL,
  price REAL NOT NULL CHECK(price >= 0),       -- per day
  description TEXT, image TEXT,
  status TEXT NOT NULL DEFAULT 'available' CHECK(status IN ('available','maintenance')),
  created TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS bookings(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  vehicle_id INTEGER NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  customer_name TEXT NOT NULL, customer_no TEXT NOT NULL, address TEXT NOT NULL, vtype TEXT,
  start_date TEXT NOT NULL, end_date TEXT NOT NULL, days INTEGER NOT NULL, total REAL NOT NULL,
  pay_method TEXT, pay_status TEXT,
  status TEXT NOT NULL DEFAULT 'Pending',      -- Pending, Approved, Rejected, Cancelled, Completed
  created TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS checkins(
  booking_id INTEGER PRIMARY KEY REFERENCES bookings(id) ON DELETE CASCADE,
  license_no TEXT NOT NULL, pickup_time TEXT NOT NULL, id_proof TEXT, notes TEXT,
  submitted TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS reviews(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_id INTEGER UNIQUE NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  vehicle_id INTEGER NOT NULL REFERENCES vehicles(id) ON DELETE CASCADE,
  rating INTEGER NOT NULL, comment TEXT,
  created TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS notifications(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  message TEXT NOT NULL, created TEXT DEFAULT CURRENT_TIMESTAMP
);
