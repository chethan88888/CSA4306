const KIND = "shop";
const STORAGE_KEY = "Q10_StyleHub_Fashion_Shop";
let cart = JSON.parse(localStorage.getItem(STORAGE_KEY + "_cart") || "[]");
function chooseItem(name) {
  if (KIND === "booking") {
    document.getElementById("chosenItem").value = name;
    document.getElementById("action").scrollIntoView({behavior:"smooth"});
  } else {
    cart.push(name); saveCart();
    document.getElementById("action").scrollIntoView({behavior:"smooth"});
  }
}
function saveCart() {
  localStorage.setItem(STORAGE_KEY + "_cart", JSON.stringify(cart));
  renderCart();
}
function renderCart() {
  const box = document.getElementById("cartSummary");
  if (box) {
    if (!cart.length) { box.textContent = "Your cart is empty."; return; }
    box.innerHTML = "<strong>Cart items (" + cart.length + ")</strong><ul>" + cart.map((x,i) => "<li>" + escapeHtml(x) + ' <button type="button" data-remove="' + i + '">Remove</button></li>').join("") + "</ul><button type='button' id='clearCart'>Clear cart</button>";
    box.querySelectorAll("[data-remove]").forEach(b => b.addEventListener("click", () => { cart.splice(Number(b.dataset.remove),1); saveCart(); }));
    document.getElementById("clearCart").addEventListener("click", () => { cart=[]; saveCart(); });
  }
  const top = document.querySelector(".topbutton");
  if (top && KIND === "shop") top.textContent = "View cart (" + cart.length + ")";
}
function escapeHtml(s) { return s.replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
const dateInput = document.getElementById("bookingDate");
if (dateInput) {
  const t = new Date();
  dateInput.min = t.getFullYear() + "-" + String(t.getMonth()+1).padStart(2,"0") + "-" + String(t.getDate()).padStart(2,"0");
}
document.getElementById("mainForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const name = document.getElementById("customerName").value.trim();
  const email = document.getElementById("customerEmail").value.trim();
  const msg = document.getElementById("message");
  if (KIND === "booking") {
    const item = document.getElementById("chosenItem").value;
    const date = document.getElementById("bookingDate").value;
    const time = document.getElementById("bookingTime").value;
    if (!item || !date || !time) { msg.textContent = "Please choose an option, date and time."; return; }
    const key = STORAGE_KEY + "_bookings";
    const records = JSON.parse(localStorage.getItem(key) || "[]");
    records.push({name,email,item,date,time,notes:document.getElementById("notes").value,status:"Confirmed (demo)",createdAt:new Date().toISOString()});
    localStorage.setItem(key,JSON.stringify(records));
    msg.textContent = "Appointment confirmed for " + item + " on " + date + " at " + time + ". Saved in this browser for demo purposes.";
    this.reset();
  } else {
    const address = document.getElementById("deliveryAddress").value.trim();
    const payment = document.getElementById("paymentMethod").value;
    if (!cart.length) { msg.textContent = "Add at least one item to your cart first."; return; }
    if (!address || !payment) { msg.textContent = "Please complete the delivery and payment fields."; return; }
    const key = STORAGE_KEY + "_orders";
    const records = JSON.parse(localStorage.getItem(key) || "[]");
    records.push({name,email,items:[...cart],address,payment,status:"Placed (demo)",createdAt:new Date().toISOString()});
    localStorage.setItem(key,JSON.stringify(records));
    const count = cart.length; cart=[]; saveCart();
    msg.textContent = "Demo order placed for " + count + " item(s). No real payment was processed.";
    this.reset();
  }
});
renderCart();
