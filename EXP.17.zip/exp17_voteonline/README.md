# Experiment 17 - VoteOnline (E-Voting Platform)

Flask + SQLite web application with **Admin** and **Voter** roles.

## Run
```bash
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py                                         # http://127.0.0.1:5000
```
`app.db` is created automatically from `schema.sql` with demo data.

## Demo accounts
| Role  | Voter ID  | Password |
|-------|-----------|----------|
| Admin | ADMIN     | admin123 |
| Voter | VOTER001 (Ward 1), VOTER002 (Ward 1), VOTER003 (Ward 2) | voter123 |

**OTP:** OTPs are shown on screen in demo mode and printed in the console (`DEMO_MODE=0` hides the on-screen copy;
plug an SMS/e-mail gateway into `send_otp()` in `common.py`).

## Features
**Voter:** login using Voter ID + password, **OTP login verification** (multi-factor), view elections for their ward with
candidate details, **Get OTP for voting**, select candidate, submit vote, confirmation receipt code, voting history,
live turnout progress (auto-refreshing), results once the election is closed.

**Admin:** create election candidates (with symbol/photo), create elections, **allocate candidates to an election** (all wards
or a specific ward), **allocate users to election wards**, create voter list (single add), **import voter list from CSV**
(`sample_voters.csv`), view & update / reset / delete voters, open/close elections, **get election results** (overall + per ward).

## Security design
- Passwords hashed; imported/created voters get a random temporary password shown once to the admin.
- OTPs are 6 digits, expire after 5 minutes, allow 5 attempts, and are bound to the session and to the election.
- **Ballot secrecy:** `votes` has no user id or timestamp; `voter_status` records only *that* a voter voted (prevents double
  voting, powers history/receipt). A voter can only vote once per election (primary key on `voter_status`).
- Voting only works while the election is `open` and only for candidates allocated to the voter's ward.
- For production add HTTPS, rate limiting, and a real SMS/e-mail OTP provider.

## Structure
`app.py` routes - `common.py` helpers - `schema.sql` tables (users, wards, elections, candidates, election_candidates,
voter_status, votes) - `templates/` - `static/`
