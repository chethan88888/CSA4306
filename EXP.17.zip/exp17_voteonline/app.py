"""VoteOnline - secure e-voting platform (Flask + SQLite)."""
import csv
import io
import os
import secrets
import string

from flask import Flask, render_template, request, redirect, url_for, flash, session, abort, jsonify
from werkzeug.security import generate_password_hash, check_password_hash

from common import (setup, query, execute, get_db, login_required, start_session, send_otp,
                    check_otp, save_upload, IMG_EXT)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-change-me")
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"


def temp_password(n=8):
    return "".join(secrets.choice(string.ascii_letters + string.digits) for _ in range(n))


def seed(db):
    if db.execute("SELECT 1 FROM users").fetchone():
        return
    for w in ("Ward 1", "Ward 2", "Ward 3"):
        db.execute("INSERT INTO wards(name) VALUES(?)", (w,))
    db.execute("INSERT INTO users(voter_id,name,email,phone,password,role) VALUES('ADMIN','Election Commissioner','admin@voteonline.test','9999999999',?,'admin')",
               (generate_password_hash("admin123"),))
    for i, (vid, name, ward) in enumerate([("VOTER001", "Asha Kumar", 1), ("VOTER002", "Ravi Shankar", 1), ("VOTER003", "Meena Iyer", 2)]):
        db.execute("INSERT INTO users(voter_id,name,email,phone,password,role,ward_id) VALUES(?,?,?,?,?,'voter',?)",
                   (vid, name, vid.lower() + "@voteonline.test", "90000000%02d" % i, generate_password_hash("voter123"), ward))
    for n, p, b in [("Anita Rao", "Unity Party", "Teacher and community organiser with 10 years of local service."),
                    ("Bala Murugan", "Progress Front", "Civil engineer focused on roads and water supply."),
                    ("Charu Latha", "Independent", "Healthcare worker campaigning for primary health centres.")]:
        db.execute("INSERT INTO candidates(name,party,bio) VALUES(?,?,?)", (n, p, b))
    db.execute("INSERT INTO elections(title,description,status) VALUES('Municipal Council Election 2026','Choose your ward representative.','open')")
    for cid in (1, 2, 3):
        db.execute("INSERT INTO election_candidates(election_id,candidate_id,ward_id) VALUES(1,?,0)", (cid,))


setup(app, seed)


@app.context_processor
def inject():
    role = session.get("role")
    nav = [("index", "Home")]
    if role == "voter":
        nav += [("voter_home", "Elections"), ("history", "My Voting History")]
    elif role == "admin":
        nav += [("admin_home", "Dashboard"), ("admin_candidates", "Candidates"), ("admin_elections", "Elections"),
                ("admin_voters", "Voter List")]
    nav.append(("logout", "Logout (%s)" % session["name"]) if role else ("login", "Voter Login"))
    return dict(brand="VoteOnline", accent="#4338ca", nav=nav)


# ---------------------------------------------------------------- helpers
def eligible_candidates(eid, ward_id):
    return query("""SELECT DISTINCT c.* FROM candidates c JOIN election_candidates ec ON ec.candidate_id=c.id
                    WHERE ec.election_id=? AND ec.ward_id IN (0, ?) ORDER BY c.name""", (eid, ward_id or -1))


def eligible_voters(eid):
    """Voters whose ward has at least one candidate in this election."""
    return query("""SELECT COUNT(*) c FROM users u WHERE u.role='voter' AND (
        EXISTS(SELECT 1 FROM election_candidates WHERE election_id=? AND ward_id=0 AND u.ward_id IS NOT NULL)
        OR EXISTS(SELECT 1 FROM election_candidates WHERE election_id=? AND ward_id=u.ward_id))""", (eid, eid), one=True)["c"]


def progress(eid):
    voted = query("SELECT COUNT(*) c FROM voter_status WHERE election_id=?", (eid,), one=True)["c"]
    total = eligible_voters(eid)
    return {"voted": voted, "eligible": total, "percent": round(100 * voted / total, 1) if total else 0}


def has_voted(eid, uid):
    return query("SELECT receipt FROM voter_status WHERE election_id=? AND user_id=?", (eid, uid), one=True)


# ------------------------------------------------------------------- auth
@app.route("/")
def index():
    elections = query("SELECT * FROM elections WHERE status!='draft' ORDER BY id DESC")
    return render_template("index.html", elections=elections)


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = query("SELECT * FROM users WHERE upper(voter_id)=upper(?)", (request.form["voter_id"].strip(),), one=True)
        if u and check_password_hash(u["password"], request.form["password"]):
            if u["role"] == "admin":
                start_session(u)
                return redirect(url_for("admin_home"))
            session.clear()
            session["pending_uid"] = u["id"]
            send_otp("login", u["phone"] or u["email"])
            return redirect(url_for("login_otp"))
        flash("Invalid Voter ID or password.", "error")
    return render_template("login.html")


@app.route("/login/otp", methods=["GET", "POST"])
def login_otp():
    uid = session.get("pending_uid")
    if not uid:
        return redirect(url_for("login"))
    if request.method == "POST":
        if request.form.get("resend"):
            u = query("SELECT * FROM users WHERE id=?", (uid,), one=True)
            send_otp("login", u["phone"])
        elif check_otp(request.form.get("otp", ""), "login"):
            start_session(query("SELECT * FROM users WHERE id=?", (uid,), one=True))
            flash("Verified. Welcome!", "success")
            return redirect(url_for("voter_home"))
        else:
            flash("Wrong or expired OTP.", "error")
    return render_template("otp.html", title="OTP Login Verification", button="Verify & Login", resend=True)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))


# ------------------------------------------------------------------ voter
@app.route("/voter")
@login_required("voter")
def voter_home():
    me = query("SELECT u.*, w.name ward FROM users u LEFT JOIN wards w ON w.id=u.ward_id WHERE u.id=?", (session["uid"],), one=True)
    rows = []
    for e in query("SELECT * FROM elections WHERE status!='draft' ORDER BY id DESC"):
        cands = eligible_candidates(e["id"], me["ward_id"])
        if cands:
            rows.append({"e": e, "n": len(cands), "voted": has_voted(e["id"], me["id"])})
    return render_template("voter_home.html", me=me, rows=rows)


@app.route("/election/<int:eid>")
@login_required("voter")
def election(eid):
    e = query("SELECT * FROM elections WHERE id=? AND status!='draft'", (eid,), one=True)
    if not e:
        abort(404)
    me = query("SELECT * FROM users WHERE id=?", (session["uid"],), one=True)
    cands = eligible_candidates(eid, me["ward_id"])
    if not cands:
        abort(403)
    return render_template("election.html", e=e, cands=cands, voted=has_voted(eid, me["id"]), prog=progress(eid))


@app.route("/api/progress/<int:eid>")
@login_required("voter", "admin")
def api_progress(eid):
    return jsonify(progress(eid))


@app.route("/election/<int:eid>/otp", methods=["POST"])
@login_required("voter")
def vote_otp(eid):
    e = query("SELECT * FROM elections WHERE id=? AND status='open'", (eid,), one=True)
    if not e or has_voted(eid, session["uid"]):
        flash("Voting is not available for this election.", "error")
        return redirect(url_for("voter_home"))
    u = query("SELECT * FROM users WHERE id=?", (session["uid"],), one=True)
    send_otp("vote-%d" % eid, u["phone"])
    return redirect(url_for("vote", eid=eid))


@app.route("/election/<int:eid>/vote", methods=["GET", "POST"])
@login_required("voter")
def vote(eid):
    e = query("SELECT * FROM elections WHERE id=? AND status='open'", (eid,), one=True)
    me = query("SELECT * FROM users WHERE id=?", (session["uid"],), one=True)
    if not e or has_voted(eid, me["id"]):
        flash("Voting is not available for this election.", "error")
        return redirect(url_for("voter_home"))
    cands = eligible_candidates(eid, me["ward_id"])
    if request.method == "POST":
        cid = request.form.get("candidate", type=int)
        if cid not in [c["id"] for c in cands]:
            flash("Select a candidate from the list.", "error")
        elif not check_otp(request.form.get("otp", ""), "vote-%d" % eid):
            flash("Wrong or expired OTP. Request a new one.", "error")
        else:
            receipt = secrets.token_hex(6).upper()
            db = get_db()
            try:
                db.execute("INSERT INTO voter_status(election_id,user_id,receipt) VALUES(?,?,?)", (eid, me["id"], receipt))
                db.execute("INSERT INTO votes(election_id,candidate_id,ward_id) VALUES(?,?,?)", (eid, cid, me["ward_id"]))
                db.commit()
            except Exception:
                db.rollback()
                flash("You have already voted in this election.", "error")
                return redirect(url_for("voter_home"))
            return redirect(url_for("receipt", eid=eid))
    if "otp" not in session or session["otp"]["purpose"] != "vote-%d" % eid:
        flash("Please request an OTP first.", "info")
        return redirect(url_for("election", eid=eid))
    return render_template("vote.html", e=e, cands=cands)


@app.route("/election/<int:eid>/receipt")
@login_required("voter")
def receipt(eid):
    r = has_voted(eid, session["uid"])
    if not r:
        abort(404)
    e = query("SELECT * FROM elections WHERE id=?", (eid,), one=True)
    st = query("SELECT * FROM voter_status WHERE election_id=? AND user_id=?", (eid, session["uid"]), one=True)
    return render_template("receipt.html", e=e, st=st)


@app.route("/history")
@login_required("voter")
def history():
    rows = query("""SELECT e.title, e.status, s.receipt, s.voted_at, e.id FROM voter_status s JOIN elections e ON e.id=s.election_id
                    WHERE s.user_id=? ORDER BY s.voted_at DESC""", (session["uid"],))
    return render_template("history.html", rows=rows)


def results_for(eid):
    rows = query("""SELECT c.id, c.name, c.party, COUNT(v.id) votes FROM candidates c
                    JOIN (SELECT DISTINCT candidate_id FROM election_candidates WHERE election_id=?) ec ON ec.candidate_id=c.id
                    LEFT JOIN votes v ON v.candidate_id=c.id AND v.election_id=? GROUP BY c.id ORDER BY votes DESC, c.name""", (eid, eid))
    by_ward = query("""SELECT COALESCE(w.name,'No ward') ward, c.name, COUNT(*) votes FROM votes v JOIN candidates c ON c.id=v.candidate_id
                       LEFT JOIN wards w ON w.id=v.ward_id WHERE v.election_id=? GROUP BY v.ward_id, c.id ORDER BY ward, votes DESC""", (eid,))
    return rows, by_ward


@app.route("/election/<int:eid>/results")
@login_required("voter", "admin")
def results(eid):
    e = query("SELECT * FROM elections WHERE id=?", (eid,), one=True)
    if not e:
        abort(404)
    if session["role"] == "voter" and e["status"] != "closed":
        flash("Results are published after the election closes.", "info")
        return redirect(url_for("election", eid=eid))
    rows, by_ward = results_for(eid)
    return render_template("results.html", e=e, rows=rows, by_ward=by_ward, total=sum(r["votes"] for r in rows), prog=progress(eid))


# ------------------------------------------------------------------ admin
@app.route("/admin")
@login_required("admin")
def admin_home():
    elections = query("SELECT * FROM elections ORDER BY id DESC")
    data = [{"e": e, "prog": progress(e["id"])} for e in elections]
    stats = {"voters": query("SELECT COUNT(*) c FROM users WHERE role='voter'", one=True)["c"],
             "unassigned": query("SELECT COUNT(*) c FROM users WHERE role='voter' AND ward_id IS NULL", one=True)["c"],
             "candidates": query("SELECT COUNT(*) c FROM candidates", one=True)["c"]}
    return render_template("admin_home.html", data=data, stats=stats)


@app.route("/admin/candidates", methods=["GET", "POST"])
@login_required("admin")
def admin_candidates():
    if request.method == "POST":
        sym = save_upload(request.files.get("symbol"), IMG_EXT)
        execute("INSERT INTO candidates(name,party,bio,symbol) VALUES(?,?,?,?)",
                (request.form["name"].strip(), request.form["party"].strip(), request.form["bio"].strip(), sym))
        flash("Candidate created.", "success")
        return redirect(url_for("admin_candidates"))
    return render_template("admin_candidates.html", rows=query("SELECT * FROM candidates ORDER BY id DESC"))


@app.route("/admin/candidates/<int:cid>/delete", methods=["POST"])
@login_required("admin")
def admin_candidate_delete(cid):
    if query("SELECT 1 FROM votes WHERE candidate_id=?", (cid,), one=True):
        flash("Cannot delete a candidate who has received votes.", "error")
    else:
        execute("DELETE FROM candidates WHERE id=?", (cid,))
        flash("Candidate deleted.", "success")
    return redirect(url_for("admin_candidates"))


@app.route("/admin/elections", methods=["GET", "POST"])
@login_required("admin")
def admin_elections():
    if request.method == "POST":
        execute("INSERT INTO elections(title,description) VALUES(?,?)", (request.form["title"].strip(), request.form["description"].strip()))
        flash("Election created (draft). Allocate candidates, then open it.", "success")
        return redirect(url_for("admin_elections"))
    return render_template("admin_elections.html", rows=query("SELECT * FROM elections ORDER BY id DESC"))


@app.route("/admin/elections/<int:eid>", methods=["GET", "POST"])
@login_required("admin")
def admin_election(eid):
    e = query("SELECT * FROM elections WHERE id=?", (eid,), one=True)
    if not e:
        abort(404)
    if request.method == "POST":
        act = request.form["action"]
        if act == "allocate":
            ward = request.form.get("ward_id", type=int) or 0
            execute("INSERT OR IGNORE INTO election_candidates(election_id,candidate_id,ward_id) VALUES(?,?,?)",
                    (eid, request.form.get("candidate_id", type=int), ward))
        elif act == "remove":
            execute("DELETE FROM election_candidates WHERE election_id=? AND candidate_id=? AND ward_id=?",
                    (eid, request.form.get("candidate_id", type=int), request.form.get("ward_id", type=int)))
        elif act in ("open", "close", "draft"):
            if act == "open" and not query("SELECT 1 FROM election_candidates WHERE election_id=?", (eid,), one=True):
                flash("Allocate at least one candidate before opening.", "error")
            else:
                execute("UPDATE elections SET status=? WHERE id=?", ({"open": "open", "close": "closed", "draft": "draft"}[act], eid))
        elif act == "delete":
            execute("DELETE FROM elections WHERE id=?", (eid,))
            return redirect(url_for("admin_elections"))
        return redirect(url_for("admin_election", eid=eid))
    alloc = query("""SELECT ec.*, c.name, c.party, COALESCE(w.name,'All wards') ward FROM election_candidates ec
                     JOIN candidates c ON c.id=ec.candidate_id LEFT JOIN wards w ON w.id=ec.ward_id WHERE ec.election_id=? ORDER BY ward, c.name""", (eid,))
    return render_template("admin_election.html", e=e, alloc=alloc, cands=query("SELECT * FROM candidates ORDER BY name"),
                           wards=query("SELECT * FROM wards ORDER BY name"), prog=progress(eid))


@app.route("/admin/voters", methods=["GET", "POST"])
@login_required("admin")
def admin_voters():
    if request.method == "POST":
        act = request.form["action"]
        if act == "ward":
            name = request.form["name"].strip()
            if name:
                execute("INSERT OR IGNORE INTO wards(name) VALUES(?)", (name,))
        elif act == "allocate":
            ids = request.form.getlist("sel", type=int)
            ward = request.form.get("ward_id", type=int)
            for i in ids:
                execute("UPDATE users SET ward_id=? WHERE id=? AND role='voter'", (ward or None, i))
            flash("%d voter(s) allocated." % len(ids), "success")
        elif act == "add":
            vid = request.form["voter_id"].strip().upper()
            if query("SELECT 1 FROM users WHERE voter_id=?", (vid,), one=True):
                flash("Voter ID already exists.", "error")
            else:
                pw = temp_password()
                execute("INSERT INTO users(voter_id,name,email,phone,password,ward_id) VALUES(?,?,?,?,?,?)",
                        (vid, request.form["name"].strip(), request.form["email"].strip(), request.form["phone"].strip(),
                         generate_password_hash(pw), request.form.get("ward_id", type=int) or None))
                flash("Voter %s created. Temporary password: %s (shown once)" % (vid, pw), "success")
        return redirect(url_for("admin_voters", **{k: v for k, v in request.args.items()}))
    q = request.args.get("q", "").strip()
    ward = request.args.get("ward", type=int)
    sql = "SELECT u.*, w.name ward FROM users u LEFT JOIN wards w ON w.id=u.ward_id WHERE u.role='voter'"
    args = []
    if q:
        sql += " AND (u.voter_id LIKE ? OR u.name LIKE ?)"
        args += ["%" + q + "%"] * 2
    if ward is not None:
        sql += " AND u.ward_id=?"
        args.append(ward)
    rows = query(sql + " ORDER BY u.voter_id", args)
    wards = query("SELECT w.*, (SELECT COUNT(*) FROM users WHERE ward_id=w.id) n FROM wards w ORDER BY name")
    return render_template("admin_voters.html", rows=rows, wards=wards, q=q, ward=ward)


@app.route("/admin/voters/import", methods=["GET", "POST"])
@login_required("admin")
def admin_import():
    created = []
    skipped = 0
    if request.method == "POST":
        f = request.files.get("file")
        if not f or not f.filename.lower().endswith(".csv"):
            flash("Upload a .csv file.", "error")
        else:
            reader = csv.DictReader(io.StringIO(f.read().decode("utf-8-sig", errors="replace")))
            reader.fieldnames = [(h or "").strip().lower() for h in (reader.fieldnames or [])]
            if "voter_id" not in reader.fieldnames or "name" not in reader.fieldnames:
                flash("CSV needs at least the columns: voter_id, name (optional: email, phone, ward).", "error")
            else:
                for r in reader:
                    vid = (r.get("voter_id") or "").strip().upper()
                    if not vid or query("SELECT 1 FROM users WHERE voter_id=?", (vid,), one=True):
                        skipped += 1
                        continue
                    wid = None
                    wname = (r.get("ward") or "").strip()
                    if wname:
                        execute("INSERT OR IGNORE INTO wards(name) VALUES(?)", (wname,))
                        wid = query("SELECT id FROM wards WHERE name=?", (wname,), one=True)["id"]
                    pw = temp_password()
                    execute("INSERT INTO users(voter_id,name,email,phone,password,ward_id) VALUES(?,?,?,?,?,?)",
                            (vid, (r.get("name") or "").strip(), (r.get("email") or "").strip(), (r.get("phone") or "").strip(),
                             generate_password_hash(pw), wid))
                    created.append((vid, r.get("name"), wname, pw))
                flash("Imported %d voters, skipped %d (blank or already existing)." % (len(created), skipped), "success")
    return render_template("admin_import.html", created=created)


@app.route("/admin/voters/<int:uid>", methods=["GET", "POST"])
@login_required("admin")
def admin_voter(uid):
    u = query("SELECT * FROM users WHERE id=? AND role='voter'", (uid,), one=True)
    if not u:
        abort(404)
    if request.method == "POST":
        act = request.form["action"]
        if act == "save":
            execute("UPDATE users SET name=?, email=?, phone=?, ward_id=? WHERE id=?",
                    (request.form["name"].strip(), request.form["email"].strip(), request.form["phone"].strip(),
                     request.form.get("ward_id", type=int) or None, uid))
            flash("Voter updated.", "success")
        elif act == "reset":
            pw = temp_password()
            execute("UPDATE users SET password=? WHERE id=?", (generate_password_hash(pw), uid))
            flash("New temporary password: %s (shown once)" % pw, "success")
        elif act == "delete":
            if query("SELECT 1 FROM voter_status WHERE user_id=?", (uid,), one=True):
                flash("Cannot delete a voter who has already voted.", "error")
            else:
                execute("DELETE FROM users WHERE id=?", (uid,))
                flash("Voter deleted.", "success")
                return redirect(url_for("admin_voters"))
        return redirect(url_for("admin_voter", uid=uid))
    return render_template("admin_voter.html", u=u, wards=query("SELECT * FROM wards ORDER BY name"))


if __name__ == "__main__":
    app.run(debug=os.environ.get("DEBUG") == "1", port=int(os.environ.get("PORT", 5000)))
