CREATE TABLE IF NOT EXISTS wards(
  id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL
);
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  voter_id TEXT UNIQUE NOT NULL,          -- login name (admins use e.g. ADMIN)
  name TEXT NOT NULL,
  email TEXT, phone TEXT,
  password TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'voter' CHECK(role IN ('voter','admin')),
  ward_id INTEGER REFERENCES wards(id) ON DELETE SET NULL,
  created TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS elections(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL, description TEXT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','open','closed')),
  created TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS candidates(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL, party TEXT, bio TEXT, symbol TEXT
);
-- ward_id = 0 means the candidate stands in every ward of that election
CREATE TABLE IF NOT EXISTS election_candidates(
  election_id INTEGER NOT NULL REFERENCES elections(id) ON DELETE CASCADE,
  candidate_id INTEGER NOT NULL REFERENCES candidates(id) ON DELETE CASCADE,
  ward_id INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(election_id, candidate_id, ward_id)
);
-- who has voted (NOT what they voted for): prevents double voting, gives voting history + receipt
CREATE TABLE IF NOT EXISTS voter_status(
  election_id INTEGER NOT NULL REFERENCES elections(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  receipt TEXT NOT NULL,
  voted_at TEXT DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(election_id, user_id)
);
-- the ballot box: deliberately has NO user_id and NO timestamp, so ballots are anonymous
CREATE TABLE IF NOT EXISTS votes(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  election_id INTEGER NOT NULL REFERENCES elections(id) ON DELETE CASCADE,
  candidate_id INTEGER NOT NULL REFERENCES candidates(id),
  ward_id INTEGER
);
